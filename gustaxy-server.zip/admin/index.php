<?php
declare(strict_types=1);
require dirname(__DIR__) . '/config/bootstrap.php';
require dirname(__DIR__) . '/app/KeyService.php';
require __DIR__ . '/_layout.php';
$user = require_admin();
$totalKeys = (int) db()->query('SELECT COUNT(*) FROM api_keys')->fetchColumn();
$activeKeys = (int) db()->query("SELECT COUNT(*) FROM api_keys WHERE status = 'active' AND expires_at > CURRENT_TIMESTAMP")->fetchColumn();
$devices = (int) db()->query('SELECT COUNT(*) FROM devices WHERE revoked_at IS NULL')->fetchColumn();
$loginCutoff = cfg('DB_DRIVER', 'mysql') === 'sqlite' ? "datetime('now', '-1 day')" : '(CURRENT_TIMESTAMP - INTERVAL 1 DAY)';
$logins24 = (int) db()->query("SELECT COUNT(*) FROM login_logs WHERE created_at >= $loginCutoff")->fetchColumn();
$keys = db()->query('SELECT id, key_prefix, max_devices, expires_at, status, created_at FROM api_keys ORDER BY id DESC LIMIT 40')->fetchAll();
render_header('Início', 'home', $user);
?><header class="topbar"><div><h1>Início</h1><p class="sub">Visão geral do acesso Gustaxy.</p></div><a class="btn primary" href="/admin/generate.php">Gerar keys</a></header>
<section class="grid"><div class="card"><div class="metric-label">Keys cadastradas</div><div class="metric"><?= $totalKeys ?></div></div><div class="card"><div class="metric-label">Keys ativas</div><div class="metric"><?= $activeKeys ?></div></div><div class="card"><div class="metric-label">Dispositivos ativos</div><div class="metric"><?= $devices ?></div></div><div class="card"><div class="metric-label">Entradas nas últimas 24h</div><div class="metric"><?= $logins24 ?></div></div></section>
<section class="section card"><div class="section-head"><h2>Keys recentes</h2><span class="muted">O valor completo só é mostrado no momento da geração.</span></div><div class="table-wrap"><table class="table"><thead><tr><th>Prefixo</th><th>Dispositivos</th><th>Expira em</th><th>Status</th><th>Ações</th></tr></thead><tbody><?php foreach ($keys as $key): $status = $key['status']; if ($status === 'active' && strtotime((string) $key['expires_at']) <= time()) $status = 'expired'; ?><tr><td><code><?= e((string) $key['key_prefix']) ?>••••</code></td><td><?= (int) $key['max_devices'] ?></td><td><?= e((string) $key['expires_at']) ?> UTC</td><td><span class="pill <?= $status === 'active' ? 'green' : ($status === 'paused' ? 'yellow' : 'red') ?>"><?= e($status) ?></span></td><td><div class="actions"><form method="post" action="/admin/action.php"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="id" value="<?= (int) $key['id'] ?>"><?php if ($status === 'active'): ?><button class="btn" name="action" value="pause">Pausar</button><?php elseif ($status === 'paused'): ?><button class="btn" name="action" value="resume">Retomar</button><?php endif; ?><button class="btn danger" name="action" value="revoke" data-confirm="Revogar esta key e seus tokens?">Revogar</button></form><a class="btn" href="/admin/logs.php?type=entry&key=<?= (int) $key['id'] ?>">Dispositivos</a></div></td></tr><?php endforeach; if (!$keys): ?><tr><td colspan="5" class="muted">Nenhuma key criada.</td></tr><?php endif; ?></tbody></table></div></section>
<?php render_footer(); ?>
