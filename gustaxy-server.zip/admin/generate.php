<?php
declare(strict_types=1);
require dirname(__DIR__) . '/config/bootstrap.php';
require dirname(__DIR__) . '/app/Settings.php';
require dirname(__DIR__) . '/app/KeyService.php';
require __DIR__ . '/_layout.php';
$user = require_admin();
$error = '';
$result = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf($_POST['csrf'] ?? null);
    try {
        $result = KeyService::generate(
            (int) ($_POST['quantity'] ?? 1),
            (int) ($_POST['max_devices'] ?? 1),
            (int) ($_POST['amount'] ?? 1),
            (string) ($_POST['unit'] ?? 'days'),
            (int) $user['id'],
            (string) ($_POST['prefix'] ?? '')
        );
    } catch (Throwable) {
        $error = 'Não foi possível gerar as keys. Verifique os valores e tente novamente.';
    }
}
$keysArePaused = Settings::keysPaused();
render_header('Gerar keys', 'keys', $user);
?><header class="topbar"><div><h1>Gerar keys</h1><p class="sub">Crie acessos temporários com prefixo, duração e limite de dispositivos.</p></div></header>
<?php if ($error): ?><p class="notice danger"><?= e($error) ?></p><?php endif; ?>
<?php if ($result): ?><section class="section card"><div class="section-head"><div><h2>Keys geradas</h2><p class="muted">As keys ficam protegidas no banco e podem ser recuperadas no painel quando necessário.</p></div><button class="btn primary" type="button" data-copy-target="generated-keys">Copiar</button></div><span class="pill <?= $result['started_paused'] ? 'yellow' : 'green' ?>"><?= $result['started_paused'] ? 'Criadas pausadas' : 'Ativas' ?></span><textarea id="generated-keys" class="key-output" readonly><?= e(implode(PHP_EOL, $result['keys'])) ?></textarea><p class="notice success">Prefixo: <?= e($result['prefix']) ?> · Expiração: <?= e($result['expires_at']) ?> UTC · <?= (int) $result['max_devices'] ?> device(s) por key<?= $result['started_paused'] ? ' · criada pausada pela pausa global' : '' ?></p></section><?php endif; ?>
<?php if ($keysArePaused): ?><p class="notice">A pausa global está ativa. As novas keys serão criadas com o prazo congelado até a despausa.</p><?php endif; ?>
<section class="section card"><form method="post" class="form-grid"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><label>Prefixo opcional<span class="field-help">Vazio = prefixo automático aleatório `GUS`.</span><input type="text" name="prefix" maxlength="20" placeholder="Ex.: VIP, TESTE, CLIENTE"></label><label>Quantidade<input type="number" name="quantity" min="1" max="500" value="1" required></label><label>Dispositivos por key<input type="number" name="max_devices" min="1" max="50" value="1" required></label><label>Período<input type="number" name="amount" min="1" max="8760" value="1" required></label><label>Unidade<select name="unit"><option value="hours">Horas</option><option value="days" selected>Dias</option><option value="weeks">Semanas</option><option value="months">Mês</option><option value="years">Ano</option></select></label><div class="wide"><button class="primary" type="submit">Gerar keys aleatórias</button></div></form></section>
<?php render_footer(); ?>
