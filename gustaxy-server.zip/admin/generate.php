<?php
declare(strict_types=1);
require dirname(__DIR__) . '/config/bootstrap.php';
require dirname(__DIR__) . '/app/KeyService.php';
require __DIR__ . '/_layout.php';
$user = require_admin();
$error = '';
$result = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf($_POST['csrf'] ?? null);
    try {
        $result = KeyService::generate((int) ($_POST['quantity'] ?? 1), (int) ($_POST['max_devices'] ?? 1), (int) ($_POST['amount'] ?? 1), (string) ($_POST['unit'] ?? 'days'), (int) $user['id']);
    } catch (Throwable $e) {
        $error = 'Não foi possível gerar as keys. Verifique os valores e tente novamente.';
    }
}
render_header('Gerar keys', 'keys', $user);
?><header class="topbar"><div><h1>Gerar keys</h1><p class="sub">Crie acessos temporários com limite de dispositivos.</p></div></header>
<?php if ($error): ?><p class="notice danger"><?= e($error) ?></p><?php endif; ?>
<?php if ($result): ?><section class="section card"><div class="section-head"><h2>Keys geradas</h2><span class="pill green">Exibição única</span></div><p class="muted">Copie agora. O banco armazena somente o fingerprint criptográfico, não o valor recuperável.</p><textarea class="key-output" readonly><?= e(implode(PHP_EOL, $result['keys'])) ?></textarea><p class="notice success">Expiração: <?= e($result['expires_at']) ?> UTC · Dispositivos por key: <?= (int) $result['max_devices'] ?></p></section><?php endif; ?>
<section class="section card"><form method="post" class="form-grid"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><label>Quantidade<input type="number" name="quantity" min="1" max="500" value="1" required></label><label>Dispositivos por key<input type="number" name="max_devices" min="1" max="50" value="1" required></label><label>Período<input type="number" name="amount" min="1" max="8760" value="1" required></label><label>Unidade<select name="unit"><option value="hours">Horas</option><option value="days" selected>Dias</option><option value="weeks">Semanas</option><option value="months">Mês</option><option value="years">Ano</option></select></label><div class="wide"><button class="primary" type="submit">Gerar keys</button></div></form></section>
<?php render_footer(); ?>
