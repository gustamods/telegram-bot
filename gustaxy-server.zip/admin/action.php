<?php
declare(strict_types=1);
require dirname(__DIR__) . '/config/bootstrap.php';
require dirname(__DIR__) . '/app/Settings.php';
require dirname(__DIR__) . '/app/KeyService.php';
$user = require_admin();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { redirect_to('/admin/index.php'); }
verify_csrf($_POST['csrf'] ?? null);
$action = (string) ($_POST['action'] ?? '');
$globalActions = ['global_pause_keys', 'global_resume_keys'];
$id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
if (!in_array($action, ['pause', 'resume', 'revoke', 'reset_device', 'reset_key', 'delete_key', 'reveal_key', ...$globalActions], true) || (!$id && !in_array($action, $globalActions, true))) {
    http_response_code(400);
    exit('Ação inválida.');
}
try {
    switch ($action) {
        case 'pause': KeyService::pause((int) $id, (int) $user['id']); break;
        case 'resume': KeyService::resume((int) $id, (int) $user['id']); break;
        case 'revoke': KeyService::revoke((int) $id, (int) $user['id']); break;
        case 'reset_device': KeyService::resetDevice((int) $id, (int) $user['id']); break;
        case 'reset_key': KeyService::resetKey((int) $id, (int) $user['id']); break;
        case 'delete_key': KeyService::delete((int) $id, (int) $user['id']); break;
        case 'reveal_key': $_SESSION['revealed_key'] = KeyService::reveal((int) $id, (int) $user['id']); break;
        case 'global_pause_keys': Settings::pauseAll((int) $user['id']); break;
        case 'global_resume_keys': Settings::resumeAll((int) $user['id']); break;
    }
} catch (Throwable) {
    http_response_code(500);
    exit('Não foi possível concluir a ação.');
}
$return = (string) ($_POST['return'] ?? '/admin/index.php');
$allowedReturns = ['/admin/index.php', '/admin/generate.php', '/admin/settings.php', '/admin/logs.php?type=system', '/admin/logs.php?type=entry'];
if (!in_array($return, $allowedReturns, true)) {
    $return = '/admin/index.php';
}
redirect_to($return);
