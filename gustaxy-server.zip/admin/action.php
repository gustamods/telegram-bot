<?php
declare(strict_types=1);
require dirname(__DIR__) . '/config/bootstrap.php';
require dirname(__DIR__) . '/app/KeyService.php';
$user = require_admin();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { redirect_to('/admin/index.php'); }
verify_csrf($_POST['csrf'] ?? null);
$action = (string) ($_POST['action'] ?? '');
$id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
if (!$id || !in_array($action, ['pause', 'resume', 'revoke', 'reset_device'], true)) { http_response_code(400); exit('Ação inválida.'); }
try {
    if ($action === 'pause') KeyService::pause((int) $id, (int) $user['id']);
    if ($action === 'resume') KeyService::resume((int) $id, (int) $user['id']);
    if ($action === 'revoke') KeyService::revoke((int) $id, (int) $user['id']);
    if ($action === 'reset_device') KeyService::resetDevice((int) $id, (int) $user['id']);
} catch (Throwable) {
    http_response_code(500);
    exit('Não foi possível concluir a ação.');
}
$return = (string) ($_POST['return'] ?? '/admin/index.php');
if (!in_array($return, ['/admin/index.php', '/admin/generate.php', '/admin/logs.php?type=system', '/admin/logs.php?type=entry'], true)) {
    $return = '/admin/index.php';
}
redirect_to($return);
