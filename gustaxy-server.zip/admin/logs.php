<?php
declare(strict_types=1);
require dirname(__DIR__) . '/config/bootstrap.php';
require __DIR__ . '/_layout.php';
$user = require_admin();
$type = ($_GET['type'] ?? 'system') === 'entry' ? 'entry' : 'system';
$keyFilter = filter_var($_GET['key'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
render_header($type === 'entry' ? 'Logs de entrada' : 'Logs do sistema', $type, $user);
?><header class="topbar"><div><h1><?= $type === 'entry' ? 'Logs de entrada' : 'Logs do sistema' ?></h1><p class="sub"><?= $type === 'entry' ? 'Dispositivos, navegador, sistema operacional e IP observado.' : 'Ações de login, keys, dispositivos e sessões administrativas.' ?></p></div></header>
<section class="section card"><div class="table-wrap"><table class="table"><thead><?php if ($type === 'system'): ?><tr><th>Evento</th><th>Administrador</th><th>Alvo</th><th>IP</th><th>Detalhes</th><th>Data</th></tr><?php else: ?><tr><th>Status</th><th>Key</th><th>Dispositivo</th><th>Navegador</th><th>Sistema</th><th>IP</th><th>Data</th></tr><?php endif; ?></thead><tbody>
<?php if ($type === 'system'):
    $rows = db()->query('SELECT a.*, u.username FROM audit_logs a LEFT JOIN admin_users u ON u.id = a.actor_user_id ORDER BY a.id DESC LIMIT 200')->fetchAll();
    foreach ($rows as $row): ?><tr><td><span class="pill <?= str_contains((string) $row['event_type'], 'failed') ? 'red' : 'green' ?>"><?= e((string) $row['event_type']) ?></span></td><td><?= e((string) ($row['username'] ?? 'sistema')) ?></td><td><?= e((string) ($row['target_type'] ?? '')) ?> #<?= e((string) ($row['target_id'] ?? '')) ?></td><td><?= e((string) $row['ip_address']) ?></td><td><code><?= e((string) ($row['metadata_json'] ?? '{}')) ?></code></td><td><?= e((string) $row['created_at']) ?> UTC</td></tr><?php endforeach;
    if (!$rows): ?><tr><td colspan="6" class="muted">Nenhum evento registrado.</td></tr><?php endif;
else:
    if ($keyFilter) { $stmt = db()->prepare('SELECT l.*, k.key_prefix FROM login_logs l LEFT JOIN api_keys k ON k.id = l.api_key_id WHERE l.api_key_id = ? ORDER BY l.id DESC LIMIT 200'); $stmt->execute([$keyFilter]); $rows = $stmt->fetchAll(); } else { $rows = db()->query('SELECT l.*, k.key_prefix FROM login_logs l LEFT JOIN api_keys k ON k.id = l.api_key_id ORDER BY l.id DESC LIMIT 200')->fetchAll(); }
    foreach ($rows as $row): ?><tr><td><span class="pill <?= (int) $row['success'] === 1 ? 'green' : 'red' ?>"><?= (int) $row['success'] === 1 ? 'sucesso' : 'falha' ?></span></td><td><?= e((string) ($row['key_prefix'] ?? 'admin')) ?></td><td><code><?= e((string) ($row['device_id_hash'] ? substr($row['device_id_hash'], 0, 16) : 'n/a')) ?></code></td><td><?= e((string) ($row['browser'] ?? 'Outro')) ?></td><td><?= e((string) ($row['operating_system'] ?? 'Outro')) ?></td><td><?= e((string) $row['ip_address']) ?></td><td><?= e((string) $row['created_at']) ?> UTC</td></tr><?php endforeach;
    if (!$rows): ?><tr><td colspan="7" class="muted">Nenhuma entrada registrada.</td></tr><?php endif;
endif; ?></tbody></table></div></section>
<?php render_footer(); ?>
