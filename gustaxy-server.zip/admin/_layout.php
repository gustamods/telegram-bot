<?php
declare(strict_types=1);
function e(string $value): string { return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function render_header(string $title, string $active, array $user): void { ?>
<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?= e($title) ?> · Gustaxy</title><link rel="stylesheet" href="/assets/css/app.css"><script src="/assets/js/app.js" defer></script></head><body>
<div class="shell"><aside class="sidebar"><a class="brand" href="/admin/index.php">Gust<span>axy</span></a><nav class="nav">
<a class="<?= $active === 'home' ? 'active' : '' ?>" href="/admin/index.php">Início</a>
<a class="<?= $active === 'keys' ? 'active' : '' ?>" href="/admin/generate.php">Gerar keys</a>
<a class="<?= $active === 'system' ? 'active' : '' ?>" href="/admin/logs.php?type=system">Logs do sistema</a>
<a class="<?= $active === 'entry' ? 'active' : '' ?>" href="/admin/logs.php?type=entry">Logs de entrada</a>
<a class="logout" href="/admin/logout.php">Sair</a>
</nav><p class="muted" style="font-size:12px;margin-top:16px">Sessão: <?= e((string) $user['username']) ?></p></aside><main class="main">
<?php }
function render_footer(): void { ?></main></div></body></html><?php }
