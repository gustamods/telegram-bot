<?php
declare(strict_types=1);
require dirname(__DIR__) . '/config/bootstrap.php';
require dirname(__DIR__) . '/app/Settings.php';
require __DIR__ . '/_layout.php';
$user = require_admin();
$error = '';
$success = '';
$settings = Settings::all();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf($_POST['csrf'] ?? null);
    try {
        $enabled = ($_POST['maintenance_enabled'] ?? '') === '1' ? '1' : '0';
        $title = mb_substr(trim((string) ($_POST['maintenance_title'] ?? '')), 0, 120);
        $description = mb_substr(trim((string) ($_POST['maintenance_description'] ?? '')), 0, 1000);
        if ($title === '') {
            throw new InvalidArgumentException('Informe um título para o diálogo.');
        }
        if ($description === '') {
            throw new InvalidArgumentException('Informe uma descrição para o diálogo.');
        }
        $imagePath = (string) ($settings['maintenance_image_path'] ?? '');
        if (isset($_FILES['maintenance_image']) && (int) $_FILES['maintenance_image']['error'] !== UPLOAD_ERR_NO_FILE) {
            $upload = $_FILES['maintenance_image'];
            if ((int) $upload['error'] !== UPLOAD_ERR_OK || (int) $upload['size'] > 2 * 1024 * 1024 || !is_uploaded_file((string) $upload['tmp_name'])) {
                throw new RuntimeException('A imagem deve ter no máximo 2 MB.');
            }
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $mime = (string) $finfo->file((string) $upload['tmp_name']);
            $extensions = ['image/png' => 'png', 'image/jpeg' => 'jpg', 'image/webp' => 'webp', 'image/gif' => 'gif'];
            if (!isset($extensions[$mime]) || @getimagesize((string) $upload['tmp_name']) === false) {
                throw new RuntimeException('Formato de imagem não permitido. Use PNG, JPG, WEBP ou GIF.');
            }
            $directory = GUSTAXY_ROOT . '/assets/uploads/maintenance';
            if (!is_dir($directory) && !mkdir($directory, 0750, true) && !is_dir($directory)) {
                throw new RuntimeException('Não foi possível preparar o diretório de imagens.');
            }
            $filename = 'maintenance_' . bin2hex(random_bytes(16)) . '.' . $extensions[$mime];
            $destination = $directory . '/' . $filename;
            if (!move_uploaded_file((string) $upload['tmp_name'], $destination)) {
                throw new RuntimeException('Não foi possível salvar a imagem.');
            }
            if (str_starts_with($imagePath, '/assets/uploads/maintenance/')) {
                $old = GUSTAXY_ROOT . $imagePath;
                if (is_file($old)) {
                    @unlink($old);
                }
            }
            $imagePath = '/assets/uploads/maintenance/' . $filename;
        }
        Settings::set('maintenance_enabled', $enabled, (int) $user['id']);
        Settings::set('maintenance_title', $title, (int) $user['id']);
        Settings::set('maintenance_description', $description, (int) $user['id']);
        Settings::set('maintenance_image_path', $imagePath, (int) $user['id']);
        audit('settings_updated', (int) $user['id'], 'global', 'maintenance', ['enabled' => $enabled, 'has_image' => $imagePath !== '']);
        $settings = Settings::all();
        $success = 'Configurações salvas com sucesso.';
    } catch (Throwable $e) {
        $error = $e instanceof InvalidArgumentException || $e instanceof RuntimeException ? $e->getMessage() : 'Não foi possível salvar as configurações.';
    }
}
$maintenance = Settings::maintenance();
render_header('Configurações', 'settings', $user);
?><header class="topbar"><div><h1>Configurações globais</h1><p class="sub">Controle o aviso de manutenção exibido no aplicativo e o estado geral das keys.</p></div></header>
<?php if ($error): ?><p class="notice danger"><?= e($error) ?></p><?php endif; ?><?php if ($success): ?><p class="notice success"><?= e($success) ?></p><?php endif; ?>
<section class="section card"><div class="section-head"><div><h2>Modo manutenção</h2><p class="muted">Quando ativo, o app mostra o diálogo configurado antes do login e a API impede novas autenticações.</p></div><span class="pill <?= $maintenance['enabled'] ? 'yellow' : 'green' ?>"><?= $maintenance['enabled'] ? 'Ativo' : 'Desativado' ?></span></div><form method="post" enctype="multipart/form-data" class="form-grid"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><label class="toggle-row"><input type="checkbox" name="maintenance_enabled" value="1" <?= $maintenance['enabled'] ? 'checked' : '' ?>><span>Ativar modo manutenção</span></label><div></div><label>Título do diálogo<input type="text" name="maintenance_title" maxlength="120" value="<?= e((string) $settings['maintenance_title']) ?>" required></label><label>Descrição<textarea name="maintenance_description" maxlength="1000" required><?= e((string) $settings['maintenance_description']) ?></textarea></label><label>Imagem opcional<span class="field-help">PNG, JPG, WEBP ou GIF; máximo de 2 MB.</span><input type="file" name="maintenance_image" accept="image/png,image/jpeg,image/webp,image/gif"></label><div class="preview-card"><?php if ($maintenance['image_path']): ?><img src="<?= e($maintenance['image_path']) ?>" alt="Imagem atual da manutenção"><span class="muted">Imagem atual</span><?php else: ?><span class="muted">Nenhuma imagem configurada.</span><?php endif; ?></div><div class="wide"><button class="primary" type="submit">Salvar configurações</button></div></form></section>
<section class="section card"><div class="section-head"><div><h2>Pausa global de keys</h2><p class="muted">Congela o tempo restante das keys ativas. Ao despausar, o período congelado é devolvido ao vencimento.</p></div><span class="pill <?= Settings::keysPaused() ? 'yellow' : 'green' ?>"><?= Settings::keysPaused() ? 'Pausadas' : 'Normais' ?></span></div><div class="actions"><form method="post" action="/admin/action.php"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="return" value="/admin/settings.php"><button class="btn" name="action" value="global_pause_keys" <?= Settings::keysPaused() ? 'disabled' : '' ?>>Pausar todas as keys</button></form><form method="post" action="/admin/action.php"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="return" value="/admin/settings.php"><button class="btn primary" name="action" value="global_resume_keys" <?= !Settings::keysPaused() ? 'disabled' : '' ?>>Despausar todas as keys</button></form></div></section>
<?php render_footer(); ?>
