<?php
declare(strict_types=1);
require dirname(__DIR__) . '/config/bootstrap.php';
require dirname(__DIR__) . '/app/Auth.php';
require __DIR__ . '/_layout.php';

if (current_user()) { redirect_to('/admin/index.php'); }
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf($_POST['csrf'] ?? null);
    $result = Auth::login((string) ($_POST['username'] ?? ''), (string) ($_POST['password'] ?? ''));
    if ($result['ok']) { redirect_to('/admin/index.php'); }
    $error = (string) $result['error'];
}
?><!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Login · Gustaxy</title><link rel="stylesheet" href="/assets/css/app.css"></head><body class="auth-page"><main class="auth-card"><div class="brand">Gust<span>axy</span></div><h1>Entrar no painel</h1><p class="muted">Acesso administrativo protegido.</p><?php if ($error): ?><p class="notice danger"><?= e($error) ?></p><?php endif; ?><form method="post" autocomplete="on"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><label>Usuário<input name="username" required maxlength="190" autocomplete="username"></label><label>Senha<input name="password" type="password" required autocomplete="current-password"></label><button class="primary" type="submit">Entrar</button></form></main></body></html>
