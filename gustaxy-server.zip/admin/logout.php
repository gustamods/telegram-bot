<?php
declare(strict_types=1);
require dirname(__DIR__) . '/config/bootstrap.php';
require dirname(__DIR__) . '/app/Auth.php';
Auth::logout();
redirect_to('/admin/login.php');
