<?php
declare(strict_types=1);

const GUSTAXY_ROOT = __DIR__ . '/..';

$configPath = getenv('GUSTAXY_CONFIG') ?: (__DIR__ . '/env.php');
if (!is_file($configPath)) {
    $configPath = __DIR__ . '/env.example.php';
}
$GLOBALS['gustaxy_config'] = require $configPath;

function cfg(string $key, mixed $default = null): mixed
{
    return $GLOBALS['gustaxy_config'][$key] ?? $default;
}

if (session_status() !== PHP_SESSION_ACTIVE) {
    $secure = (bool) cfg('COOKIE_SECURE', true);
    session_name('gustaxy_admin');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => $secure,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

function db(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }

    $driver = (string) cfg('DB_DRIVER', 'mysql');
    if ($driver === 'sqlite') {
        $path = (string) cfg('DB_PATH', GUSTAXY_ROOT . '/storage/gustaxy.sqlite');
        if (!is_dir(dirname($path))) {
            mkdir(dirname($path), 0700, true);
        }
        $dsn = 'sqlite:' . $path;
        $pdo = new PDO($dsn);
    } else {
        $dsn = sprintf('mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4', cfg('DB_HOST'), cfg('DB_PORT', '3306'), cfg('DB_NAME'));
        $pdo = new PDO($dsn, (string) cfg('DB_USER'), (string) cfg('DB_PASS'));
    }
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
    return $pdo;
}

function app_key(): string
{
    $key = (string) cfg('APP_KEY', '');
    if (strlen($key) < 32 || str_contains($key, 'gere-uma-chave')) {
        throw new RuntimeException('APP_KEY não configurada.');
    }
    return $key;
}

function b64url_encode(string $value): string
{
    return rtrim(strtr(base64_encode($value), '+/', '-_'), '=');
}

function random_token(int $bytes = 32): string
{
    return b64url_encode(random_bytes($bytes));
}

function json_input(): array
{
    if ((int) ($_SERVER['CONTENT_LENGTH'] ?? 0) > 65536) {
        json_response(['error' => 'Payload muito grande.'], 413);
    }
    $raw = file_get_contents('php://input') ?: '';
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

function json_response(array $payload, int $status = 200): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function redirect_to(string $path): never
{
    header('Location: ' . $path, true, 303);
    exit;
}

function client_ip(): string
{
    if ((bool) cfg('TRUST_PROXY', false) && !empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $first = trim(explode(',', (string) $_SERVER['HTTP_X_FORWARDED_FOR'])[0]);
        if (filter_var($first, FILTER_VALIDATE_IP)) {
            return $first;
        }
    }
    return filter_var($_SERVER['REMOTE_ADDR'] ?? '', FILTER_VALIDATE_IP) ?: '0.0.0.0';
}

function normalize_fingerprint(string $value): string
{
    return strtoupper(str_replace([':', '-', ' '], '', trim($value)));
}

function user_agent(): string
{
    return mb_substr((string) ($_SERVER['HTTP_USER_AGENT'] ?? 'unknown'), 0, 512);
}

function client_context(): array
{
    $ua = strtolower(user_agent());
    $browser = str_contains($ua, 'edg/') ? 'Edge' : (str_contains($ua, 'chrome') ? 'Google Chrome' : (str_contains($ua, 'firefox') ? 'Firefox' : (str_contains($ua, 'safari') ? 'Safari' : 'Outro')));
    $os = str_contains($ua, 'android') ? 'Android' : (str_contains($ua, 'iphone') || str_contains($ua, 'ipad') ? 'iOS' : (str_contains($ua, 'linux') ? 'Linux' : (str_contains($ua, 'windows') ? 'Windows' : (str_contains($ua, 'mac') ? 'macOS' : 'Outro'))));
    return ['browser' => $browser, 'os' => $os, 'ip' => client_ip(), 'user_agent' => user_agent()];
}

function security_headers(): void
{
    header('X-Frame-Options: DENY');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: no-referrer');
    header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
    header("Content-Security-Policy: default-src 'self'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:");
    if ((bool) cfg('COOKIE_SECURE', true)) {
        header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
    }
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = random_token(32);
    }
    return (string) $_SESSION['csrf'];
}

function verify_csrf(?string $token): void
{
    if (!$token || !hash_equals((string) ($_SESSION['csrf'] ?? ''), $token)) {
        http_response_code(419);
        exit('Sessão expirada. Recarregue a página.');
    }
}

function current_user(): ?array
{
    $id = $_SESSION['user_id'] ?? null;
    if (!$id) {
        return null;
    }
    $idle = (int) cfg('SESSION_IDLE_TTL', 1800);
    if (!empty($_SESSION['last_seen']) && time() - (int) $_SESSION['last_seen'] > $idle) {
        $_SESSION = [];
        session_destroy();
        return null;
    }
    $_SESSION['last_seen'] = time();
    $stmt = db()->prepare('SELECT id, username, role, is_active FROM admin_users WHERE id = ? LIMIT 1');
    $stmt->execute([(int) $id]);
    $user = $stmt->fetch();
    return ($user && (int) $user['is_active'] === 1) ? $user : null;
}

function require_admin(): array
{
    $user = current_user();
    if (!$user) {
        redirect_to('/admin/login.php');
    }
    return $user;
}

function audit(string $event, ?int $actorId = null, ?string $targetType = null, ?string $targetId = null, array $metadata = []): void
{
    $stmt = db()->prepare('INSERT INTO audit_logs (event_type, actor_user_id, target_type, target_id, metadata_json, ip_address, user_agent, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)');
    $stmt->execute([$event, $actorId, $targetType, $targetId, json_encode($metadata, JSON_UNESCAPED_UNICODE), client_ip(), user_agent()]);
}

function rate_limit(string $bucket, int $max, int $windowSeconds): bool
{
    $dir = GUSTAXY_ROOT . '/storage/ratelimit';
    if (!is_dir($dir)) {
        mkdir($dir, 0700, true);
    }
    $file = $dir . '/' . hash('sha256', $bucket . '|' . client_ip()) . '.json';
    $fh = fopen($file, 'c+');
    if (!$fh) {
        return false;
    }
    flock($fh, LOCK_EX);
    $raw = stream_get_contents($fh);
    $state = is_string($raw) ? json_decode($raw, true) : null;
    $now = time();
    if (!is_array($state) || ($now - (int) ($state['started'] ?? 0)) >= $windowSeconds) {
        $state = ['started' => $now, 'count' => 0];
    }
    $state['count']++;
    ftruncate($fh, 0);
    rewind($fh);
    fwrite($fh, json_encode($state));
    fflush($fh);
    flock($fh, LOCK_UN);
    fclose($fh);
    if ((int) $state['count'] > $max) {
        header('Retry-After: ' . max(1, $windowSeconds - ($now - (int) $state['started'])));
        return false;
    }
    return true;
}

function method(string $expected): void
{
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== $expected) {
        header('Allow: ' . $expected);
        json_response(['error' => 'Método não permitido.'], 405);
    }
}

security_headers();
