<?php
declare(strict_types=1);

return [
    'APP_ENV' => 'production',
    'APP_NAME' => 'Gustaxy Admin',
    'APP_URL' => 'https://SEU-DOMINIO.example',
    'APP_KEY' => 'gere-uma-chave-hexadecimal-de-64-caracteres',
    'SETUP_TOKEN' => 'defina-um-token-longo-e-remova-setup.php-depois',
    'DB_DRIVER' => 'mysql',
    'DB_HOST' => 'localhost',
    'DB_PORT' => '3306',
    'DB_NAME' => 'gustaxy',
    'DB_USER' => 'gustaxy_user',
    'DB_PASS' => 'troque-esta-senha',
    'DB_PATH' => __DIR__ . '/../storage/gustaxy.sqlite',
    'COOKIE_SECURE' => true,
    'TRUST_PROXY' => false,
    'CORS_ORIGIN' => '',
    'EXPECTED_CERT_SHA256' => '',
    'API_TOKEN_TTL' => 86400,
    'SESSION_IDLE_TTL' => 1800,
];
