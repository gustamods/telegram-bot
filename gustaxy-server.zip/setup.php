<?php
declare(strict_types=1);
require __DIR__ . '/config/bootstrap.php';

if (!rate_limit('setup', 5, 300)) {
    http_response_code(429);
    exit('Tente novamente mais tarde.');
}
$count = (int) db()->query('SELECT COUNT(*) FROM admin_users')->fetchColumn();
$token = (string) ($_GET['token'] ?? $_POST['token'] ?? '');
$validToken = $token !== '' && hash_equals((string) cfg('SETUP_TOKEN', ''), $token) && strlen((string) cfg('SETUP_TOKEN', '')) >= 32;
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $count === 0 && $validToken) {
    $username = trim((string) ($_POST['username'] ?? ''));
    $password = (string) ($_POST['password'] ?? '');
    if (!preg_match('/^[A-Za-z0-9_.@-]{3,190}$/', $username) || strlen($password) < 12) {
        $message = 'Informe um usuário válido e uma senha com pelo menos 12 caracteres.';
    } else {
        $algorithm = defined('PASSWORD_ARGON2ID') ? PASSWORD_ARGON2ID : PASSWORD_DEFAULT;
        $stmt = db()->prepare('INSERT INTO admin_users (username, password_hash, role, is_active, created_at) VALUES (?, ?, \'admin\', 1, CURRENT_TIMESTAMP)');
        $stmt->execute([$username, password_hash($password, $algorithm)]);
        audit('initial_admin_created', (int) db()->lastInsertId(), 'admin_user', (string) db()->lastInsertId());
        $message = 'Administrador criado. Remova ou bloqueie setup.php e entre no painel.';
        $count = 1;
    }
}
?><!doctype html>
<html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Gustaxy setup</title><link rel="stylesheet" href="/assets/css/app.css"></head>
<body class="auth-page"><main class="auth-card"><div class="brand">Gustaxy</div><h1>Configuração inicial</h1>
<?php if ($count > 0): ?><p class="notice">O painel já possui administrador. Bloqueie setup.php e use o login.</p>
<?php elseif (!$validToken): ?><p class="notice danger">Token de configuração ausente ou inválido.</p>
<?php else: ?><form method="post" autocomplete="off"><input type="hidden" name="token" value="<?= e($token) ?>"><label>Usuário<input name="username" required maxlength="190" autocomplete="username"></label><label>Senha<input type="password" name="password" required minlength="12" autocomplete="new-password"></label><button class="primary" type="submit">Criar administrador</button></form><?php endif; ?>
<?php if ($message): ?><p class="notice"><?= e($message) ?></p><?php endif; ?></main></body></html>
<?php
function e(string $value): string { return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
