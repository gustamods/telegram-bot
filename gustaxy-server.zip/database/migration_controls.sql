-- Gustaxy controls migration; safe to run after database.sql.
ALTER TABLE api_keys ADD COLUMN IF NOT EXISTS pause_started_at DATETIME NULL AFTER paused_at;

CREATE TABLE IF NOT EXISTS app_settings (
  setting_key VARCHAR(80) NOT NULL,
  setting_value TEXT NOT NULL,
  updated_by INT UNSIGNED NULL,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (setting_key),
  CONSTRAINT fk_settings_admin FOREIGN KEY (updated_by) REFERENCES admin_users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO app_settings (setting_key, setting_value) VALUES
  ('maintenance_enabled', '0'),
  ('maintenance_title', 'Manutenção programada'),
  ('maintenance_description', 'O aplicativo está temporariamente em manutenção. Tente novamente mais tarde.'),
  ('maintenance_image_path', ''),
  ('keys_paused', '0')
ON DUPLICATE KEY UPDATE setting_key = VALUES(setting_key);
