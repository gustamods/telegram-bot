<?php
declare(strict_types=1);

final class KeyService
{
    public static function fingerprint(string $rawKey): string
    {
        return hash_hmac('sha256', trim($rawKey), app_key());
    }

    public static function deviceHash(string $deviceId): string
    {
        return hash_hmac('sha256', trim($deviceId), app_key());
    }

    private static function encryptionKey(): string
    {
        return hash('sha256', app_key(), true);
    }

    private static function encryptKey(string $rawKey): string
    {
        $iv = random_bytes(12);
        $tag = '';
        $ciphertext = openssl_encrypt($rawKey, 'aes-256-gcm', self::encryptionKey(), OPENSSL_RAW_DATA, $iv, $tag, 'gustaxy-key-v1');
        if ($ciphertext === false || strlen($tag) !== 16) {
            throw new RuntimeException('Não foi possível proteger a key.');
        }
        return base64_encode($iv . $tag . $ciphertext);
    }

    private static function decryptKey(string $payload): string
    {
        $decoded = base64_decode($payload, true);
        if ($decoded === false || strlen($decoded) < 28) {
            throw new RuntimeException('Key não recuperável.');
        }
        $iv = substr($decoded, 0, 12);
        $tag = substr($decoded, 12, 16);
        $ciphertext = substr($decoded, 28);
        $rawKey = openssl_decrypt($ciphertext, 'aes-256-gcm', self::encryptionKey(), OPENSSL_RAW_DATA, $iv, $tag, 'gustaxy-key-v1');
        if ($rawKey === false || $rawKey === '') {
            throw new RuntimeException('Key não recuperável.');
        }
        return $rawKey;
    }

    public static function reveal(int $id, int $actorId): string
    {
        $stmt = db()->prepare('SELECT key_prefix, key_ciphertext FROM api_keys WHERE id = ? LIMIT 1');
        $stmt->execute([$id]);
        $key = $stmt->fetch();
        if (!$key || empty($key['key_ciphertext'])) {
            throw new RuntimeException('Esta key foi criada antes da recuperação segura e precisa ser gerada novamente.');
        }
        $rawKey = self::decryptKey((string) $key['key_ciphertext']);
        audit('key_revealed', $actorId, 'api_key', (string) $id, ['key_prefix' => (string) $key['key_prefix']]);
        return $rawKey;
    }

    public static function expiresAt(int $amount, string $unit): string
    {
        $amount = max(1, min($amount, 8760));
        $allowed = ['hour' => 'hour', 'hours' => 'hour', 'day' => 'day', 'days' => 'day', 'week' => 'week', 'weeks' => 'week', 'month' => 'month', 'months' => 'month', 'year' => 'year', 'years' => 'year'];
        if (!isset($allowed[$unit])) {
            throw new InvalidArgumentException('Período inválido.');
        }
        $dt = new DateTimeImmutable('now', new DateTimeZone('UTC'));
        return $dt->modify('+' . $amount . ' ' . $allowed[$unit])->format('Y-m-d H:i:s');
    }

    public static function normalizePrefix(string $prefix): string
    {
        $prefix = strtoupper(trim($prefix));
        $prefix = preg_replace('/[^A-Z0-9_-]+/', '-', $prefix) ?? '';
        $prefix = trim(substr($prefix, 0, 20), '-_');
        return $prefix !== '' ? $prefix : 'GUS';
    }

    public static function generate(int $quantity, int $maxDevices, int $amount, string $unit, int $actorId, string $prefix = ''): array
    {
        $quantity = max(1, min($quantity, 500));
        $maxDevices = max(1, min($maxDevices, 50));
        $expires = self::expiresAt($amount, $unit);
        $prefix = self::normalizePrefix($prefix);
        $paused = class_exists('Settings') && Settings::keysPaused();
        $pdo = db();
        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare('INSERT INTO api_keys (key_prefix, key_hash, key_ciphertext, max_devices, expires_at, status, created_by, created_at, pause_started_at) VALUES (?, ?, ?, ?, ?, \'active\', ?, CURRENT_TIMESTAMP, ?)');
            $plain = [];
            for ($i = 0; $i < $quantity; $i++) {
                $raw = $prefix . '-' . strtoupper(bin2hex(random_bytes(3))) . '-' . strtoupper(b64url_encode(random_bytes(18)));
                $stmt->execute([substr($raw, 0, 24), self::fingerprint($raw), self::encryptKey($raw), $maxDevices, $expires, $actorId, $paused ? gmdate('Y-m-d H:i:s') : null]);
                $plain[] = $raw;
            }
            $pdo->commit();
            audit('keys_generated', $actorId, 'api_key', null, ['quantity' => $quantity, 'prefix' => $prefix, 'max_devices' => $maxDevices, 'expires_at' => $expires, 'started_paused' => $paused]);
            return ['keys' => $plain, 'expires_at' => $expires, 'max_devices' => $maxDevices, 'prefix' => $prefix, 'started_paused' => $paused];
        } catch (Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
    }

    public static function pause(int $id, int $actorId): void
    {
        $stmt = db()->prepare("UPDATE api_keys SET status = 'paused', paused_at = COALESCE(paused_at, CURRENT_TIMESTAMP) WHERE id = ? AND status = 'active'");
        $stmt->execute([$id]);
        audit('key_paused', $actorId, 'api_key', (string) $id);
    }

    public static function resume(int $id, int $actorId): void
    {
        $pdo = db();
        $stmt = $pdo->prepare("SELECT expires_at, paused_at FROM api_keys WHERE id = ? AND status = 'paused' LIMIT 1");
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        if (!$row) {
            return;
        }
        $expires = new DateTimeImmutable((string) $row['expires_at'], new DateTimeZone('UTC'));
        $pausedAt = !empty($row['paused_at']) ? new DateTimeImmutable((string) $row['paused_at'], new DateTimeZone('UTC')) : new DateTimeImmutable('now', new DateTimeZone('UTC'));
        $seconds = max(0, time() - $pausedAt->getTimestamp());
        $newExpires = $expires->modify('+' . $seconds . ' seconds')->format('Y-m-d H:i:s');
        $pdo->prepare("UPDATE api_keys SET expires_at = ?, status = 'active', paused_at = NULL WHERE id = ?")->execute([$newExpires, $id]);
        audit('key_resumed', $actorId, 'api_key', (string) $id, ['paused_seconds' => $seconds]);
    }

    public static function revoke(int $id, int $actorId): void
    {
        $stmt = db()->prepare("UPDATE api_keys SET status = 'revoked', revoked_at = CURRENT_TIMESTAMP, paused_at = NULL, pause_started_at = NULL WHERE id = ? AND status <> 'revoked'");
        $stmt->execute([$id]);
        db()->prepare('UPDATE api_tokens SET revoked_at = CURRENT_TIMESTAMP WHERE api_key_id = ?')->execute([$id]);
        audit('key_revoked', $actorId, 'api_key', (string) $id);
    }

    public static function resetDevice(int $id, int $actorId): void
    {
        $deviceStmt = db()->prepare('SELECT api_key_id, device_id_hash FROM devices WHERE id = ? LIMIT 1');
        $deviceStmt->execute([$id]);
        $device = $deviceStmt->fetch();
        if (!$device) {
            throw new RuntimeException('Dispositivo não encontrado.');
        }
        db()->prepare('UPDATE devices SET revoked_at = CURRENT_TIMESTAMP WHERE id = ?')->execute([$id]);
        db()->prepare('UPDATE api_tokens SET revoked_at = CURRENT_TIMESTAMP WHERE api_key_id = ? AND device_id_hash = ?')->execute([(int) $device['api_key_id'], (string) $device['device_id_hash']]);
        audit('device_reset', $actorId, 'device', (string) $id, ['api_key_id' => (int) $device['api_key_id']]);
    }

    public static function resetKey(int $id, int $actorId): void
    {
        db()->prepare('UPDATE devices SET revoked_at = CURRENT_TIMESTAMP WHERE api_key_id = ? AND revoked_at IS NULL')->execute([$id]);
        db()->prepare('UPDATE api_tokens SET revoked_at = CURRENT_TIMESTAMP WHERE api_key_id = ?')->execute([$id]);
        audit('key_devices_reset', $actorId, 'api_key', (string) $id);
    }

    public static function delete(int $id, int $actorId): void
    {
        $stmt = db()->prepare('SELECT key_prefix FROM api_keys WHERE id = ? LIMIT 1');
        $stmt->execute([$id]);
        $key = $stmt->fetch();
        if (!$key) {
            throw new RuntimeException('Key não encontrada.');
        }
        audit('key_deleted', $actorId, 'api_key', (string) $id, ['key_prefix' => (string) $key['key_prefix']]);
        db()->prepare('DELETE FROM api_keys WHERE id = ?')->execute([$id]);
    }
}
