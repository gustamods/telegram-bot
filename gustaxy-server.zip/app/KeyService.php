<?php
declare(strict_types=1);

final class KeyService
{
    public static function fingerprint(string $rawKey): string
    {
        return hash_hmac('sha256', trim($rawKey), app_key());
    }

    public static function deviceHash(string $deviceId): string
    {
        return hash_hmac('sha256', trim($deviceId), app_key());
    }

    public static function expiresAt(int $amount, string $unit): string
    {
        $amount = max(1, min($amount, 8760));
        $allowed = ['hour' => 'hour', 'hours' => 'hour', 'day' => 'day', 'days' => 'day', 'week' => 'week', 'weeks' => 'week', 'month' => 'month', 'months' => 'month', 'year' => 'year', 'years' => 'year'];
        if (!isset($allowed[$unit])) {
            throw new InvalidArgumentException('Período inválido.');
        }
        $dt = new DateTimeImmutable('now', new DateTimeZone('UTC'));
        return $dt->modify('+' . $amount . ' ' . $allowed[$unit])->format('Y-m-d H:i:s');
    }

    public static function generate(int $quantity, int $maxDevices, int $amount, string $unit, int $actorId): array
    {
        $quantity = max(1, min($quantity, 500));
        $maxDevices = max(1, min($maxDevices, 50));
        $expires = self::expiresAt($amount, $unit);
        $pdo = db();
        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare('INSERT INTO api_keys (key_prefix, key_hash, max_devices, expires_at, status, created_by, created_at) VALUES (?, ?, ?, ?, \'active\', ?, CURRENT_TIMESTAMP)');
            $plain = [];
            for ($i = 0; $i < $quantity; $i++) {
                $raw = 'GUS-' . strtoupper(bin2hex(random_bytes(3))) . '-' . strtoupper(b64url_encode(random_bytes(18)));
                $stmt->execute([substr($raw, 0, 12), self::fingerprint($raw), $maxDevices, $expires, $actorId]);
                $plain[] = $raw;
            }
            $pdo->commit();
            audit('keys_generated', $actorId, 'api_key', null, ['quantity' => $quantity, 'max_devices' => $maxDevices, 'expires_at' => $expires]);
            return ['keys' => $plain, 'expires_at' => $expires, 'max_devices' => $maxDevices];
        } catch (Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
    }

    public static function pause(int $id, int $actorId): void
    {
        $stmt = db()->prepare("UPDATE api_keys SET status = 'paused', paused_at = CURRENT_TIMESTAMP WHERE id = ? AND status = 'active'");
        $stmt->execute([$id]);
        audit('key_paused', $actorId, 'api_key', (string) $id);
    }

    public static function resume(int $id, int $actorId): void
    {
        $stmt = db()->prepare("UPDATE api_keys SET status = 'active', paused_at = NULL WHERE id = ? AND status = 'paused'");
        $stmt->execute([$id]);
        audit('key_resumed', $actorId, 'api_key', (string) $id);
    }

    public static function revoke(int $id, int $actorId): void
    {
        $stmt = db()->prepare("UPDATE api_keys SET status = 'revoked', revoked_at = CURRENT_TIMESTAMP WHERE id = ? AND status <> 'revoked'");
        $stmt->execute([$id]);
        db()->prepare('UPDATE api_tokens SET revoked_at = CURRENT_TIMESTAMP WHERE api_key_id = ?')->execute([$id]);
        audit('key_revoked', $actorId, 'api_key', (string) $id);
    }

    public static function resetDevice(int $id, int $actorId): void
    {
        $stmt = db()->prepare('UPDATE devices SET revoked_at = CURRENT_TIMESTAMP WHERE id = ?');
        $stmt->execute([$id]);
        audit('device_reset', $actorId, 'device', (string) $id);
    }
}
