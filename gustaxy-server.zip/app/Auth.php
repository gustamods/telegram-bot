<?php
declare(strict_types=1);

final class Auth
{
    public static function login(string $username, string $password): array
    {
        if (!rate_limit('admin-login', 12, 60)) {
            return ['ok' => false, 'error' => 'Não foi possível concluir o login agora. Tente novamente mais tarde.'];
        }
        $username = mb_substr(trim($username), 0, 190);
        $stmt = db()->prepare('SELECT * FROM admin_users WHERE username = ? LIMIT 1');
        $stmt->execute([$username]);
        $user = $stmt->fetch();
        $dummy = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC7VQ1gO5V5A5hT9u8iK';
        $validPassword = password_verify($password, $user['password_hash'] ?? $dummy);
        $locked = $user && !empty($user['locked_until']) && strtotime((string) $user['locked_until']) > time();
        $active = $user && (int) $user['is_active'] === 1;
        $ok = $user && $active && !$locked && $validPassword;
        $ctx = client_context();

        $log = db()->prepare('INSERT INTO login_logs (admin_user_id, success, browser, operating_system, ip_address, user_agent, created_at) VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)');
        $log->execute([$user['id'] ?? null, $ok ? 1 : 0, $ctx['browser'], $ctx['os'], $ctx['ip'], $ctx['user_agent']]);

        if (!$ok) {
            if ($user) {
                $attempts = (int) $user['failed_attempts'] + 1;
                $delay = $attempts >= 5 ? min(900, 2 ** min(9, $attempts - 4)) : 0;
                $until = $delay ? gmdate('Y-m-d H:i:s', time() + $delay) : null;
                $update = db()->prepare('UPDATE admin_users SET failed_attempts = ?, locked_until = ? WHERE id = ?');
                $update->execute([$attempts, $until, $user['id']]);
            }
            audit('admin_login_failed', $user['id'] ?? null, 'admin_user', isset($user['id']) ? (string) $user['id'] : null, ['username_supplied' => $username !== '']);
            return ['ok' => false, 'error' => 'Usuário ou senha inválidos.'];
        }

        $reset = db()->prepare('UPDATE admin_users SET failed_attempts = 0, locked_until = NULL, last_login_at = CURRENT_TIMESTAMP WHERE id = ?');
        $reset->execute([$user['id']]);
        session_regenerate_id(true);
        $_SESSION['user_id'] = (int) $user['id'];
        $_SESSION['last_seen'] = time();
        $_SESSION['csrf'] = random_token(32);
        audit('admin_login_success', (int) $user['id'], 'admin_user', (string) $user['id'], ['browser' => $ctx['browser'], 'os' => $ctx['os']]);
        return ['ok' => true];
    }

    public static function logout(): void
    {
        $user = current_user();
        if ($user) {
            audit('admin_logout', (int) $user['id'], 'admin_user', (string) $user['id']);
        }
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $params['path'], '', (bool) $params['secure'], (bool) $params['httponly']);
        }
        session_destroy();
    }
}
