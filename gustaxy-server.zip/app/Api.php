<?php
declare(strict_types=1);

final class Api
{
    public static function login(array $input): never
    {
        if (!rate_limit('api-login', 20, 60)) {
            json_response(['error' => 'Não foi possível concluir a solicitação agora.'], 429);
        }
        $rawKey = trim((string) ($input['key'] ?? ''));
        $deviceId = trim((string) ($input['device_id'] ?? ''));
        $deviceName = mb_substr(trim((string) ($input['device_name'] ?? 'Android')), 0, 120);
        $appVersion = mb_substr(trim((string) ($input['app_version'] ?? '')), 0, 32);
        $androidVersion = mb_substr(trim((string) ($input['android_version'] ?? '')), 0, 32);
        $certificateSha256 = normalize_fingerprint((string) ($input['cert_sha256'] ?? ''));
        $expectedCertificate = normalize_fingerprint((string) cfg('EXPECTED_CERT_SHA256', ''));
        if ($expectedCertificate !== '' && !hash_equals($expectedCertificate, $certificateSha256)) {
            self::logApiLogin(null, KeyService::deviceHash($deviceId), false);
            json_response(['error' => 'Aplicativo não autorizado.'], 403);
        }
        if ($rawKey === '' || strlen($deviceId) < 8 || strlen($deviceId) > 256 || strlen($rawKey) > 256) {
            json_response(['error' => 'Credenciais inválidas.'], 401);
        }
        $keyHash = KeyService::fingerprint($rawKey);
        $deviceHash = KeyService::deviceHash($deviceId);
        $stmt = db()->prepare('SELECT * FROM api_keys WHERE key_hash = ? LIMIT 1');
        $stmt->execute([$keyHash]);
        $key = $stmt->fetch();
        $valid = $key && $key['status'] === 'active' && strtotime((string) $key['expires_at']) > time();
        if (!$valid) {
            self::logApiLogin(null, $deviceHash, false);
            json_response(['error' => 'Credenciais inválidas.'], 401);
        }

        $existing = db()->prepare('SELECT * FROM devices WHERE api_key_id = ? AND device_id_hash = ? LIMIT 1');
        $existing->execute([(int) $key['id'], $deviceHash]);
        $device = $existing->fetch();
        if ($device && !empty($device['revoked_at'])) {
            json_response(['error' => 'Dispositivo não autorizado.'], 403);
        }
        if (!$device) {
            $count = db()->prepare('SELECT COUNT(*) FROM devices WHERE api_key_id = ? AND revoked_at IS NULL');
            $count->execute([(int) $key['id']]);
            if ((int) $count->fetchColumn() >= (int) $key['max_devices']) {
                self::logApiLogin((int) $key['id'], $deviceHash, false);
                json_response(['error' => 'Limite de dispositivos atingido.'], 403);
            }
            $insert = db()->prepare('INSERT INTO devices (api_key_id, device_id_hash, device_name, app_version, android_version, first_seen_at, last_seen_at, login_count) VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 1)');
            $insert->execute([(int) $key['id'], $deviceHash, $deviceName, $appVersion, $androidVersion]);
        } else {
            $update = db()->prepare('UPDATE devices SET device_name = ?, app_version = ?, android_version = ?, last_seen_at = CURRENT_TIMESTAMP, login_count = login_count + 1 WHERE id = ?');
            $update->execute([$deviceName, $appVersion, $androidVersion, (int) $device['id']]);
        }

        $token = random_token(48);
        $tokenHash = hash_hmac('sha256', $token, app_key());
        $ttl = min((int) cfg('API_TOKEN_TTL', 86400), max(60, strtotime((string) $key['expires_at']) - time()));
        $expires = gmdate('Y-m-d H:i:s', time() + $ttl);
        $insertToken = db()->prepare('INSERT INTO api_tokens (token_hash, api_key_id, device_id_hash, expires_at, created_at, last_seen_at) VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)');
        $insertToken->execute([$tokenHash, (int) $key['id'], $deviceHash, $expires]);
        self::logApiLogin((int) $key['id'], $deviceHash, true);
        audit('api_login_success', null, 'api_key', (string) $key['id'], ['device_hash_prefix' => substr($deviceHash, 0, 12), 'cert_sha256_prefix' => substr($certificateSha256, 0, 12)]);
        json_response(['token' => $token, 'expires_at' => $expires, 'key_expires_at' => $key['expires_at'], 'device_limit' => (int) $key['max_devices']]);
    }

    public static function current(): never
    {
        $session = self::bearer();
        json_response(['authenticated' => true, 'key_expires_at' => $session['key']['expires_at'], 'device_id' => substr($session['token']['device_id_hash'], 0, 12)]);
    }

    public static function logout(): never
    {
        $session = self::bearer();
        db()->prepare('UPDATE api_tokens SET revoked_at = CURRENT_TIMESTAMP WHERE id = ?')->execute([(int) $session['token']['id']]);
        audit('api_logout', null, 'api_key', (string) $session['key']['id']);
        json_response(['ok' => true]);
    }

    private static function bearer(): array
    {
        if (!rate_limit('api-request', 120, 60)) {
            json_response(['error' => 'Muitas solicitações.'], 429);
        }
        $header = (string) ($_SERVER['HTTP_AUTHORIZATION'] ?? '');
        if (!preg_match('/^Bearer\s+([A-Za-z0-9_\-]+)$/', $header, $m)) {
            json_response(['error' => 'Não autenticado.'], 401);
        }
        $hash = hash_hmac('sha256', $m[1], app_key());
        $stmt = db()->prepare('SELECT t.*, k.expires_at AS key_expires_at, k.status AS key_status FROM api_tokens t JOIN api_keys k ON k.id = t.api_key_id WHERE t.token_hash = ? AND t.revoked_at IS NULL LIMIT 1');
        $stmt->execute([$hash]);
        $token = $stmt->fetch();
        if (!$token || strtotime((string) $token['expires_at']) <= time() || $token['key_status'] !== 'active' || strtotime((string) $token['key_expires_at']) <= time()) {
            json_response(['error' => 'Não autenticado.'], 401);
        }
        db()->prepare('UPDATE api_tokens SET last_seen_at = CURRENT_TIMESTAMP WHERE id = ?')->execute([(int) $token['id']]);
        $key = ['id' => $token['api_key_id'], 'expires_at' => $token['key_expires_at']];
        return ['token' => $token, 'key' => $key];
    }

    private static function logApiLogin(?int $keyId, string $deviceHash, bool $success): void
    {
        $ctx = client_context();
        $stmt = db()->prepare('INSERT INTO login_logs (api_key_id, device_id_hash, success, browser, operating_system, ip_address, user_agent, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)');
        $stmt->execute([$keyId, $deviceHash, $success ? 1 : 0, $ctx['browser'], $ctx['os'], $ctx['ip'], $ctx['user_agent']]);
    }
}
