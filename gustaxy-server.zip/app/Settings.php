<?php
declare(strict_types=1);

final class Settings
{
    private const DEFAULTS = [
        'maintenance_enabled' => '0',
        'maintenance_title' => 'Manutenção programada',
        'maintenance_description' => 'O aplicativo está temporariamente em manutenção. Tente novamente mais tarde.',
        'maintenance_image_path' => '',
        'keys_paused' => '0',
    ];

    public static function all(): array
    {
        $values = self::DEFAULTS;
        try {
            $rows = db()->query('SELECT setting_key, setting_value FROM app_settings')->fetchAll();
            foreach ($rows as $row) {
                $key = (string) $row['setting_key'];
                if (array_key_exists($key, $values)) {
                    $values[$key] = (string) ($row['setting_value'] ?? '');
                }
            }
        } catch (Throwable) {
            // The migration is applied during deployment; defaults keep old installs readable meanwhile.
        }
        return $values;
    }

    public static function get(string $key, mixed $default = null): mixed
    {
        $all = self::all();
        return array_key_exists($key, $all) ? $all[$key] : $default;
    }

    public static function maintenance(): array
    {
        $all = self::all();
        return [
            'enabled' => $all['maintenance_enabled'] === '1',
            'title' => $all['maintenance_title'],
            'description' => $all['maintenance_description'],
            'image_path' => $all['maintenance_image_path'],
        ];
    }

    public static function keysPaused(): bool
    {
        return (string) self::get('keys_paused', '0') === '1';
    }

    public static function set(string $key, string $value, ?int $actorId = null): void
    {
        if (!array_key_exists($key, self::DEFAULTS)) {
            throw new InvalidArgumentException('Configuração inválida.');
        }
        $pdo = db();
        if ((string) cfg('DB_DRIVER', 'mysql') === 'sqlite') {
            $stmt = $pdo->prepare('INSERT INTO app_settings (setting_key, setting_value, updated_by, updated_at) VALUES (?, ?, ?, CURRENT_TIMESTAMP) ON CONFLICT(setting_key) DO UPDATE SET setting_value = excluded.setting_value, updated_by = excluded.updated_by, updated_at = CURRENT_TIMESTAMP');
        } else {
            $stmt = $pdo->prepare('INSERT INTO app_settings (setting_key, setting_value, updated_by, updated_at) VALUES (?, ?, ?, CURRENT_TIMESTAMP) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_by = VALUES(updated_by), updated_at = CURRENT_TIMESTAMP');
        }
        $stmt->execute([$key, $value, $actorId]);
    }

    public static function pauseAll(int $actorId): void
    {
        if (self::keysPaused()) {
            return;
        }
        db()->prepare("UPDATE api_keys SET pause_started_at = CURRENT_TIMESTAMP WHERE status = 'active' AND pause_started_at IS NULL")->execute();
        self::set('keys_paused', '1', $actorId);
        audit('keys_paused_global', $actorId, 'global', 'keys');
    }

    public static function resumeAll(int $actorId): void
    {
        if (!self::keysPaused()) {
            return;
        }
        $pdo = db();
        $pdo->beginTransaction();
        try {
            $rows = $pdo->query("SELECT id, expires_at, pause_started_at FROM api_keys WHERE status = 'active' AND pause_started_at IS NOT NULL")->fetchAll();
            $update = $pdo->prepare('UPDATE api_keys SET expires_at = ?, pause_started_at = NULL WHERE id = ?');
            $now = new DateTimeImmutable('now', new DateTimeZone('UTC'));
            foreach ($rows as $row) {
                $expires = new DateTimeImmutable((string) $row['expires_at'], new DateTimeZone('UTC'));
                $pausedAt = new DateTimeImmutable((string) $row['pause_started_at'], new DateTimeZone('UTC'));
                $seconds = max(0, $now->getTimestamp() - $pausedAt->getTimestamp());
                $update->execute([$expires->modify('+' . $seconds . ' seconds')->format('Y-m-d H:i:s'), (int) $row['id']]);
            }
            self::set('keys_paused', '0', $actorId);
            $pdo->commit();
            audit('keys_resumed_global', $actorId, 'global', 'keys', ['adjusted_keys' => count($rows)]);
        } catch (Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
    }
}
