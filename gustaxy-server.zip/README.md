# Gustaxy Server

Painel administrativo e API PHP para o Gustaxy Android. O pacote foi desenhado para hospedagem compartilhada com PHP 8.1+ e MySQL/MariaDB, como o x10 Hosting.

## Estrutura

`admin/` contém o painel responsivo com login, início, geração de keys, logs do sistema, logs de entrada e logout. `api/v1/` contém os endpoints JSON usados pelo APK. `database/database.sql` é o schema MySQL/MariaDB para importar no painel do host. `config/env.example.php` é um modelo; crie `config/env.php` fora do controle de versão com valores reais. `storage/` guarda somente rate-limit temporário e banco local de teste, e está bloqueado pelo `.htaccess`.

## Instalação no x10

Crie um banco MySQL e um usuário com o menor privilégio necessário. Importe `database/database.sql` pelo phpMyAdmin. Envie os arquivos do pacote para o diretório público, preferencialmente mantendo `config/`, `app/`, `database/` e `storage/` fora do document root quando o painel permitir; se o host exigir um único diretório, os `.htaccess` e as regras de bloqueio já incluídas impedem acesso direto aos arquivos privados.

Copie `config/env.example.php` para `config/env.php` e preencha `APP_URL`, uma `APP_KEY` aleatória com pelo menos 32 bytes representados em hexadecimal, um `SETUP_TOKEN` aleatório longo, e as credenciais MySQL. Em produção, use `COOKIE_SECURE=true` somente com HTTPS ativo. Aponte o domínio para HTTPS antes do primeiro login.

Abra `https://SEU-DOMINIO/setup.php?token=SEU_SETUP_TOKEN`, crie o primeiro administrador com senha de pelo menos 12 caracteres, e depois remova `setup.php` ou bloqueie-o no painel. Nunca commit `config/env.php` nem o token real.

## API

`POST /api/v1/auth/login` recebe `key`, `device_id`, `device_name`, `app_version` e `android_version`, e devolve um token de sessão temporário. `GET /api/v1/auth/me` e `POST /api/v1/auth/logout` usam `Authorization: Bearer TOKEN`. O servidor guarda apenas fingerprints HMAC de keys, devices e tokens. A chave fixa embutida no APK não é usada como segredo de autenticação; HTTPS, tokens temporários, limite de dispositivos, revogação e, quando distribuído pela Google Play, Play Integrity são os controles de confiança.

## Pentest autorizado

O roteiro local verifica configuração, rotas, autenticação, CSRF, rate limiting, SQL injection básico por entradas controladas, XSS refletido, path traversal, métodos HTTP, headers e exposição de arquivos. Ele não executa DoS, destrói banco, usa payloads destrutivos ou ataca terceiros. O teste em produção só deve ser executado depois que o usuário confirmar o domínio correto e uma janela de manutenção.
