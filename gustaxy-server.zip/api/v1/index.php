<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/config/bootstrap.php';
require dirname(__DIR__, 2) . '/app/Settings.php';
require dirname(__DIR__, 2) . '/app/KeyService.php';
require dirname(__DIR__, 2) . '/app/Api.php';

$path = trim(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/', '/');
$input = json_input();
if ($path === 'api/v1/config') {
    method('GET');
    Api::config();
}
if ($path === 'api/v1/auth/login') {
    method('POST');
    Api::login($input);
}
if ($path === 'api/v1/auth/me') {
    method('GET');
    Api::current();
}
if ($path === 'api/v1/auth/logout') {
    method('POST');
    Api::logout();
}
json_response(['error' => 'Endpoint não encontrado.'], 404);
