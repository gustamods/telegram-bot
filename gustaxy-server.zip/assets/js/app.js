document.addEventListener('click', function (event) {
  const button = event.target.closest('[data-confirm]');
  if (button && !window.confirm(button.dataset.confirm)) {
    event.preventDefault();
    return;
  }

  const copyButton = event.target.closest('[data-copy-target]');
  if (!copyButton) return;
  const target = document.getElementById(copyButton.dataset.copyTarget);
  if (!target) return;
  target.select();
  navigator.clipboard?.writeText(target.value).then(() => {
    const original = copyButton.textContent;
    copyButton.textContent = 'Copiado';
    window.setTimeout(() => { copyButton.textContent = original; }, 1400);
  }).catch(() => {
    document.execCommand('copy');
    copyButton.textContent = 'Copiado';
    window.setTimeout(() => { copyButton.textContent = 'Copiar'; }, 1400);
  });
});
