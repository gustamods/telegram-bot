<?php
declare(strict_types=1);
require __DIR__ . '/config/bootstrap.php';
if (($_SERVER['REQUEST_URI'] ?? '/') === '/health.php') {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok' => true, 'service' => 'gustaxy']);
    exit;
}
redirect_to('/admin/login.php');
