<?php
declare(strict_types=1);
$config = require __DIR__ . '/../config/env.example.php';
$config['APP_ENV'] = 'testing';
$config['APP_KEY'] = getenv('GUSTAXY_TEST_APP_KEY') ?: bin2hex(random_bytes(32));
$config['SETUP_TOKEN'] = getenv('GUSTAXY_TEST_SETUP_TOKEN') ?: bin2hex(random_bytes(32));
$config['DB_DRIVER'] = 'sqlite';
$config['DB_PATH'] = getenv('GUSTAXY_TEST_DB') ?: (__DIR__ . '/../storage/gustaxy.sqlite');
file_put_contents(__DIR__ . '/../config/env.test.php', '<?php return ' . var_export($config, true) . ';' . PHP_EOL);
putenv('GUSTAXY_CONFIG=' . __DIR__ . '/../config/env.test.php');
require __DIR__ . '/../config/bootstrap.php';
$sql = file_get_contents(__DIR__ . '/../database/sqlite.sql');
db()->exec($sql);
echo "SQLite initialized\n";
