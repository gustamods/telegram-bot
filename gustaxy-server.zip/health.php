<?php
declare(strict_types=1);
require __DIR__ . '/config/bootstrap.php';
header('Content-Type: application/json; charset=utf-8');
try {
    db()->query('SELECT 1');
    echo json_encode(['ok' => true, 'service' => 'gustaxy', 'time' => gmdate('c')]);
} catch (Throwable) {
    http_response_code(503);
    echo json_encode(['ok' => false]);
}
