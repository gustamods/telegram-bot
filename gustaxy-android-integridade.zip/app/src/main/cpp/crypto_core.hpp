#pragma once
#include <cstdint>
#include <cstring>
#include <cstddef>
#include <string>

// SHA-256 (FIPS 180-4) — implementação portátil em C++ puro, sem dependências.
namespace gustacrypto {

struct Sha256 {
    uint32_t h[8];
    uint64_t bitlen;
    uint8_t buf[64];
    size_t buflen;

    static uint32_t rotr(uint32_t x, uint32_t n) { return (x >> n) | (x << (32 - n)); }

    void init() {
        static const uint32_t iv[8] = {
            0x6a09e667u, 0xbb67ae85u, 0x3c6ef372u, 0xa54ff53au,
            0x510e527fu, 0x9b05688cu, 0x1f83d9abu, 0x5be0cd19u
        };
        std::memcpy(h, iv, sizeof(iv));
        bitlen = 0;
        buflen = 0;
    }

    void transform(const uint8_t block[64]) {
        static const uint32_t k[64] = {
            0x428a2f98u,0x71374491u,0xb5c0fbcfu,0xe9b5dba5u,0x3956c25bu,0x59f111f1u,0x923f82a4u,0xab1c5ed5u,
            0xd807aa98u,0x12835b01u,0x243185beu,0x550c7dc3u,0x72be5d74u,0x80deb1feu,0x9bdc06a7u,0xc19bf174u,
            0xe49b69c1u,0xefbe4786u,0x0fc19dc6u,0x240ca1ccu,0x2de92c6fu,0x4a7484aau,0x5cb0a9dcu,0x76f988dau,
            0x983e5152u,0xa831c66du,0xb00327c8u,0xbf597fc7u,0xc6e00bf3u,0xd5a79147u,0x06ca6351u,0x14292967u,
            0x27b70a85u,0x2e1b2138u,0x4d2c6dfcu,0x53380d13u,0x650a7354u,0x766a0abbu,0x81c2c92eu,0x92722c85u,
            0xa2bfe8a1u,0xa81a664bu,0xc24b8b70u,0xc76c51a3u,0xd192e819u,0xd6990624u,0xf40e3585u,0x106aa070u,
            0x19a4c116u,0x1e376c08u,0x2748774cu,0x34b0bcb5u,0x391c0cb3u,0x4ed8aa4au,0x5b9cca4fu,0x682e6ff3u,
            0x748f82eeu,0x78a5636fu,0x84c87814u,0x8cc70208u,0x90befffau,0xa4506cebu,0xbef9a3f7u,0xc67178f2u
        };
        uint32_t w[64];
        for (int i = 0; i < 16; i++) {
            w[i] = (uint32_t(block[i*4]) << 24) | (uint32_t(block[i*4+1]) << 16) |
                   (uint32_t(block[i*4+2]) << 8) | uint32_t(block[i*4+3]);
        }
        for (int i = 16; i < 64; i++) {
            uint32_t s0 = rotr(w[i-15], 7) ^ rotr(w[i-15], 18) ^ (w[i-15] >> 3);
            uint32_t s1 = rotr(w[i-2], 17) ^ rotr(w[i-2], 19) ^ (w[i-2] >> 10);
            w[i] = w[i-16] + s0 + w[i-7] + s1;
        }
        uint32_t a=h[0],b=h[1],c=h[2],d=h[3],e=h[4],f=h[5],g=h[6],hh=h[7];
        for (int i = 0; i < 64; i++) {
            uint32_t S1 = rotr(e,6) ^ rotr(e,11) ^ rotr(e,25);
            uint32_t ch = (e & f) ^ ((~e) & g);
            uint32_t temp1 = hh + S1 + ch + k[i] + w[i];
            uint32_t S0 = rotr(a,2) ^ rotr(a,13) ^ rotr(a,22);
            uint32_t maj = (a & b) ^ (a & c) ^ (b & c);
            uint32_t temp2 = S0 + maj;
            hh = g; g = f; f = e; e = d + temp1;
            d = c; c = b; b = a; a = temp1 + temp2;
        }
        h[0]+=a; h[1]+=b; h[2]+=c; h[3]+=d; h[4]+=e; h[5]+=f; h[6]+=g; h[7]+=hh;
    }

    void update(const uint8_t* data, size_t len) {
        bitlen += uint64_t(len) * 8;
        while (len > 0) {
            size_t take = 64 - buflen;
            if (take > len) take = len;
            std::memcpy(buf + buflen, data, take);
            buflen += take;
            data += take;
            len -= take;
            if (buflen == 64) {
                transform(buf);
                buflen = 0;
            }
        }
    }

    void final(uint8_t out[32]) {
        uint8_t pad[72];
        size_t padlen = 0;
        pad[padlen++] = 0x80;
        size_t rem = (buflen + 1) % 64;
        size_t zeros = (rem <= 56) ? (56 - rem) : (120 - rem);
        for (size_t i = 0; i < zeros; i++) pad[padlen++] = 0x00;
        uint64_t bl = bitlen;
        for (int i = 7; i >= 0; i--) pad[padlen++] = uint8_t((bl >> (i*8)) & 0xff);
        update(pad, padlen); // note: this re-enters update/transform correctly since padlen completes the block(s)
        for (int i = 0; i < 8; i++) {
            out[i*4] = uint8_t((h[i] >> 24) & 0xff);
            out[i*4+1] = uint8_t((h[i] >> 16) & 0xff);
            out[i*4+2] = uint8_t((h[i] >> 8) & 0xff);
            out[i*4+3] = uint8_t(h[i] & 0xff);
        }
    }
};

inline void sha256(const uint8_t* data, size_t len, uint8_t out[32]) {
    Sha256 ctx;
    ctx.init();
    ctx.update(data, len);
    ctx.final(out);
}

inline void hmac_sha256(const uint8_t* key, size_t keylen, const uint8_t* data, size_t datalen, uint8_t out[32]) {
    uint8_t k0[64];
    std::memset(k0, 0, sizeof(k0));
    if (keylen > 64) {
        sha256(key, keylen, k0); // reduces to 32 bytes, rest already zero
    } else {
        std::memcpy(k0, key, keylen);
    }
    uint8_t ipad[64], opad[64];
    for (int i = 0; i < 64; i++) {
        ipad[i] = k0[i] ^ 0x36;
        opad[i] = k0[i] ^ 0x5c;
    }
    Sha256 inner;
    inner.init();
    inner.update(ipad, 64);
    inner.update(data, datalen);
    uint8_t innerHash[32];
    inner.final(innerHash);

    Sha256 outer;
    outer.init();
    outer.update(opad, 64);
    outer.update(innerHash, 32);
    outer.final(out);
}

} // namespace gustacrypto

namespace gustacrypto {

inline int hexNibble(char c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}

// Decodifica uma string hex (minúscula ou maiúscula) para bytes. Ignora
// caracteres inválidos silenciosamente (não deveria ocorrer em uso normal,
// já que a origem sempre gera hex puro).
inline size_t hexDecode(const char* hexStr, size_t hexLen, uint8_t* out, size_t outCap) {
    size_t outLen = 0;
    size_t i = 0;
    while (i + 1 < hexLen + 1 && i < hexLen && outLen < outCap) {
        int hi = hexNibble(hexStr[i]);
        if (hi < 0 || i + 1 >= hexLen) break;
        int lo = hexNibble(hexStr[i + 1]);
        if (lo < 0) break;
        out[outLen++] = static_cast<uint8_t>((hi << 4) | lo);
        i += 2;
    }
    return outLen;
}

inline std::string hexEncodeLower(const uint8_t* data, size_t len) {
    static const char* d = "0123456789abcdef";
    std::string out;
    out.reserve(len * 2);
    for (size_t i = 0; i < len; i++) {
        out.push_back(d[data[i] >> 4]);
        out.push_back(d[data[i] & 0xf]);
    }
    return out;
}

inline std::string hexEncodeUpper(const uint8_t* data, size_t len) {
    static const char* d = "0123456789ABCDEF";
    std::string out;
    out.reserve(len * 2);
    for (size_t i = 0; i < len; i++) {
        out.push_back(d[data[i] >> 4]);
        out.push_back(d[data[i] & 0xf]);
    }
    return out;
}

} // namespace gustacrypto
