#include <jni.h>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <new>
#include "crypto_core.hpp"

// Segredo de integridade embutido em build time (hex puro, sem separadores).
// Vazio em builds sem GUSTAXY_INTEGRITY_SECRET configurado (ex.: debug local):
// nesse caso nativeIntegritySignal devolve string vazia e o app simplesmente
// não envia native_signal/nonce, mesmo comportamento gracioso já usado para
// EXPECTED_CERT_SHA256/EXPECTED_APK_SHA256 em branco.
#ifndef GUSTAXY_INTEGRITY_SECRET_HEX
#define GUSTAXY_INTEGRITY_SECRET_HEX ""
#endif

using namespace gustacrypto;

extern "C" JNIEXPORT jbyteArray JNICALL
Java_com_gustaxy_android_security_NativeSecurity_nativeSha256(JNIEnv* env, jobject /*thiz*/, jbyteArray data) {
    if (data == nullptr) return nullptr;
    jsize len = env->GetArrayLength(data);
    jbyte* elems = env->GetByteArrayElements(data, nullptr);
    if (elems == nullptr) return nullptr;

    uint8_t digest[32];
    sha256(reinterpret_cast<const uint8_t*>(elems), static_cast<size_t>(len), digest);
    env->ReleaseByteArrayElements(data, elems, JNI_ABORT);

    jbyteArray result = env->NewByteArray(32);
    if (result == nullptr) return nullptr;
    env->SetByteArrayRegion(result, 0, 32, reinterpret_cast<const jbyte*>(digest));
    return result;
}

// API de hash incremental — usada para o APK inteiro (pode ter vários MB).
// Evita carregar o arquivo inteiro em memória: o Kotlin lê em blocos de 8KB
// (igual ao FileInputStream original) e só repassa cada bloco pra cá.
extern "C" JNIEXPORT jlong JNICALL
Java_com_gustaxy_android_security_NativeSecurity_nativeHashInit(JNIEnv* /*env*/, jobject /*thiz*/) {
    auto* ctx = new (std::nothrow) Sha256();
    if (ctx == nullptr) return 0;
    ctx->init();
    return reinterpret_cast<jlong>(ctx);
}

extern "C" JNIEXPORT void JNICALL
Java_com_gustaxy_android_security_NativeSecurity_nativeHashUpdate(
    JNIEnv* env, jobject /*thiz*/, jlong handle, jbyteArray chunk, jint len) {
    if (handle == 0 || chunk == nullptr || len <= 0) return;
    auto* ctx = reinterpret_cast<Sha256*>(handle);
    jbyte* elems = env->GetByteArrayElements(chunk, nullptr);
    if (elems == nullptr) return;
    ctx->update(reinterpret_cast<const uint8_t*>(elems), static_cast<size_t>(len));
    env->ReleaseByteArrayElements(chunk, elems, JNI_ABORT);
}

// Sempre libera o contexto nativo, mesmo que só queira abortar (handle
// inválido não faz nada). Kotlin deve chamar isso exatamente uma vez por
// nativeHashInit(), inclusive no caminho de erro (try/finally).
extern "C" JNIEXPORT jbyteArray JNICALL
Java_com_gustaxy_android_security_NativeSecurity_nativeHashFinal(JNIEnv* env, jobject /*thiz*/, jlong handle) {
    if (handle == 0) return nullptr;
    auto* ctx = reinterpret_cast<Sha256*>(handle);
    uint8_t digest[32];
    ctx->final(digest);
    delete ctx;
    jbyteArray result = env->NewByteArray(32);
    if (result == nullptr) return nullptr;
    env->SetByteArrayRegion(result, 0, 32, reinterpret_cast<const jbyte*>(digest));
    return result;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_gustaxy_android_security_NativeSecurity_nativeIntegritySignal(
    JNIEnv* env, jobject /*thiz*/, jbyteArray certHash, jbyteArray apkHash, jstring deviceId, jstring nonce) {
    static const char* secretHex = GUSTAXY_INTEGRITY_SECRET_HEX;
    const size_t secretHexLen = std::strlen(secretHex);
    if (secretHexLen == 0 || certHash == nullptr || apkHash == nullptr || deviceId == nullptr || nonce == nullptr) {
        return env->NewStringUTF("");
    }

    uint8_t secretBytes[128];
    const size_t secretLen = hexDecode(secretHex, secretHexLen, secretBytes, sizeof(secretBytes));
    if (secretLen == 0) {
        return env->NewStringUTF("");
    }

    jsize certLen = env->GetArrayLength(certHash);
    jbyte* certElems = env->GetByteArrayElements(certHash, nullptr);
    jsize apkLen = env->GetArrayLength(apkHash);
    jbyte* apkElems = env->GetByteArrayElements(apkHash, nullptr);
    const char* deviceChars = env->GetStringUTFChars(deviceId, nullptr);
    const char* nonceChars = env->GetStringUTFChars(nonce, nullptr);

    // Mesma ordem/formatação usada no servidor (Api.php::login):
    // CERT_HASH_HEX_UPPER | APK_HASH_HEX_UPPER | device_id | nonce
    std::string payload;
    if (certElems != nullptr) {
        payload += hexEncodeUpper(reinterpret_cast<const uint8_t*>(certElems), static_cast<size_t>(certLen));
    }
    payload += "|";
    if (apkElems != nullptr) {
        payload += hexEncodeUpper(reinterpret_cast<const uint8_t*>(apkElems), static_cast<size_t>(apkLen));
    }
    payload += "|";
    if (deviceChars != nullptr) payload += deviceChars;
    payload += "|";
    if (nonceChars != nullptr) payload += nonceChars;

    uint8_t signature[32];
    hmac_sha256(secretBytes, secretLen, reinterpret_cast<const uint8_t*>(payload.data()), payload.size(), signature);
    const std::string signalHex = hexEncodeLower(signature, 32);
    std::memset(secretBytes, 0, sizeof(secretBytes));

    if (certElems != nullptr) env->ReleaseByteArrayElements(certHash, certElems, JNI_ABORT);
    if (apkElems != nullptr) env->ReleaseByteArrayElements(apkHash, apkElems, JNI_ABORT);
    if (deviceChars != nullptr) env->ReleaseStringUTFChars(deviceId, deviceChars);
    if (nonceChars != nullptr) env->ReleaseStringUTFChars(nonce, nonceChars);

    return env->NewStringUTF(signalHex.c_str());
}

// Comparação em tempo constante (não sai mais cedo na primeira diferença),
// evita que o tempo de resposta vaze informação sobre onde a string diverge.
extern "C" JNIEXPORT jboolean JNICALL
Java_com_gustaxy_android_security_NativeSecurity_nativeSecureEquals(JNIEnv* env, jobject /*thiz*/, jstring a, jstring b) {
    if (a == nullptr || b == nullptr) return JNI_FALSE;
    const char* ca = env->GetStringUTFChars(a, nullptr);
    const char* cb = env->GetStringUTFChars(b, nullptr);
    jboolean result = JNI_FALSE;
    if (ca != nullptr && cb != nullptr) {
        const size_t la = std::strlen(ca);
        const size_t lb = std::strlen(cb);
        if (la == lb) {
            unsigned char diff = 0;
            for (size_t i = 0; i < la; i++) {
                diff = static_cast<unsigned char>(diff | (static_cast<unsigned char>(ca[i]) ^ static_cast<unsigned char>(cb[i])));
            }
            result = (diff == 0) ? JNI_TRUE : JNI_FALSE;
        }
    }
    if (ca != nullptr) env->ReleaseStringUTFChars(a, ca);
    if (cb != nullptr) env->ReleaseStringUTFChars(b, cb);
    return result;
}

// Checagem de depurador/tracer via /proc/self/status (TracerPid). Complementa
// (não substitui) Debug.isDebuggerConnected()/waitingForDebugger() do lado Kotlin.
extern "C" JNIEXPORT jboolean JNICALL
Java_com_gustaxy_android_security_NativeSecurity_nativeDebuggerAttached(JNIEnv* /*env*/, jobject /*thiz*/) {
    FILE* f = fopen("/proc/self/status", "r");
    if (f == nullptr) return JNI_FALSE;
    char line[256];
    jboolean attached = JNI_FALSE;
    while (fgets(line, sizeof(line), f) != nullptr) {
        if (std::strncmp(line, "TracerPid:", 10) == 0) {
            attached = (std::atoi(line + 10) != 0) ? JNI_TRUE : JNI_FALSE;
            break;
        }
    }
    fclose(f);
    return attached;
}
