package com.gustaxy.android.security

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Debug
import com.gustaxy.android.BuildConfig
import java.io.FileInputStream
import java.util.Locale
import java.util.UUID

/**
 * Camada de integridade do app. As partes sensíveis (hash de verdade,
 * comparação, assinatura HMAC do sinal enviado ao servidor) rodam em C++
 * dentro de libgusta.so — não como bytecode Kotlin, que qualquer
 * descompilador (Jadx) devolve praticamente pronto para ler e remendar.
 *
 * O boolean [Report.acceptable] é só um atalho de UX local (evita abrir a
 * tela de login para depois o servidor recusar). A autoridade de verdade é o
 * servidor: ele recalcula o HMAC de [Report.nativeSignal] de forma
 * independente a partir do cert_sha256/apk_sha256/device_id/nonce recebidos e
 * só aceita o login se bater. Um boolean local remendado não passa disso.
 */
object NativeSecurity {
    private var nativeLoaded = false

    init {
        nativeLoaded = try {
            System.loadLibrary("gusta")
            true
        } catch (_: UnsatisfiedLinkError) {
            false
        }
    }

    private external fun nativeSha256(data: ByteArray): ByteArray
    private external fun nativeHashInit(): Long
    private external fun nativeHashUpdate(handle: Long, chunk: ByteArray, len: Int)
    private external fun nativeHashFinal(handle: Long): ByteArray
    private external fun nativeIntegritySignal(certHash: ByteArray, apkHash: ByteArray, deviceId: String, nonce: String): String
    private external fun nativeSecureEquals(a: String, b: String): Boolean
    private external fun nativeDebuggerAttached(): Boolean

    data class Report(
        val nativeLoaded: Boolean,
        val certificateSha256: String,
        val apkSha256: String,
        val signatureMatches: Boolean,
        val apkMatches: Boolean,
        val debuggerAttached: Boolean,
        val nonce: String,
        val nativeSignal: String,
    ) {
        val acceptable: Boolean
            get() = nativeLoaded && signatureMatches && apkMatches && !debuggerAttached
    }

    /** [deviceId] deve ser o mesmo valor enviado em /auth/login (liga o sinal a este dispositivo). */
    fun inspect(context: Context, deviceId: String): Report {
        val certBytes = if (nativeLoaded) certificateBytes(context) else null
        val certDigest = certBytes?.let { runCatching { nativeSha256(it) }.getOrNull() }
        val apkDigest = if (nativeLoaded) nativeFileSha256(context.applicationInfo.sourceDir) else null
        val cert = certDigest?.let { hex(it) } ?: ""
        val apk = apkDigest?.let { hex(it) } ?: ""
        val expectedCert = normalize(BuildConfig.EXPECTED_CERT_SHA256)
        val expectedApk = normalize(BuildConfig.EXPECTED_APK_SHA256)
        val nonce = UUID.randomUUID().toString()
        val signal = if (nativeLoaded && certDigest != null && apkDigest != null) {
            runCatching { nativeIntegritySignal(certDigest, apkDigest, deviceId, nonce) }.getOrDefault("")
        } else ""
        return Report(
            nativeLoaded = nativeLoaded,
            certificateSha256 = cert,
            apkSha256 = apk,
            signatureMatches = expectedCert.isBlank() || (nativeLoaded && cert.isNotBlank() && nativeSecureEquals(cert, expectedCert)),
            apkMatches = expectedApk.isBlank() || (nativeLoaded && apk.isNotBlank() && nativeSecureEquals(apk, expectedApk)),
            debuggerAttached = Debug.isDebuggerConnected() || Debug.waitingForDebugger() ||
                (nativeLoaded && runCatching { nativeDebuggerAttached() }.getOrDefault(false)),
            nonce = nonce,
            nativeSignal = signal,
        )
    }

    private fun certificateBytes(context: Context): ByteArray? = runCatching {
        val packageInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            context.packageManager.getPackageInfo(context.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
        } else {
            @Suppress("DEPRECATION")
            context.packageManager.getPackageInfo(context.packageName, PackageManager.GET_SIGNATURES)
        }
        val signature = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            packageInfo.signingInfo?.apkContentsSigners?.firstOrNull()
        } else {
            @Suppress("DEPRECATION")
            packageInfo.signatures?.firstOrNull()
        } ?: return@runCatching null
        signature.toByteArray()
    }.getOrNull()

    /** Hash do APK em streaming (blocos de 8KB), igual ao FileInputStream original —
     *  só que a soma em si acontece nativamente. Sempre libera o contexto nativo,
     *  mesmo se a leitura falhar no meio do caminho. */
    private fun nativeFileSha256(path: String): ByteArray? {
        val handle = runCatching { nativeHashInit() }.getOrNull()?.takeIf { it != 0L } ?: return null
        return try {
            FileInputStream(path).use { input ->
                val buffer = ByteArray(8192)
                while (true) {
                    val count = input.read(buffer)
                    if (count <= 0) break
                    nativeHashUpdate(handle, buffer, count)
                }
            }
            runCatching { nativeHashFinal(handle) }.getOrNull()
        } catch (_: Exception) {
            runCatching { nativeHashFinal(handle) } // ainda libera o contexto nativo no erro
            null
        }
    }

    private fun normalize(value: String): String = value.replace(":", "").replace("-", "").trim().uppercase(Locale.ROOT)

    private fun hex(bytes: ByteArray): String = bytes.joinToString("") { "%02X".format(Locale.ROOT, it) }
}
