package com.gustaxy.android

import android.content.ClipboardManager
import android.graphics.Bitmap
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ContentPaste
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Key
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gustaxy.android.network.ApiClient
import com.gustaxy.android.security.DeviceInfo
import com.gustaxy.android.security.NativeSecurity
import com.gustaxy.android.ui.theme.GustaxyAndroidTheme
import kotlinx.coroutines.launch

class LoginActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            GustaxyAndroidTheme {
                LoginScreen(
                    onSuccess = {
                        startActivity(android.content.Intent(this, DashboardActivity::class.java))
                        finish()
                    },
                    onInvalidIntegrity = { finishAndRemoveTask() }
                )
            }
        }
    }
}

@Composable
private fun LoginScreen(onSuccess: () -> Unit, onInvalidIntegrity: () -> Unit) {
    val context = LocalContext.current
    val client = remember(context) { ApiClient(context) }
    var key by rememberSaveable { mutableStateOf(client.savedKey().orEmpty()) }
    var loading by rememberSaveable { mutableStateOf(false) }
    var message by rememberSaveable { mutableStateOf<String?>(null) }
    var maintenance by remember { mutableStateOf<ApiClient.MaintenanceInfo?>(null) }
    var maintenanceImage by remember { mutableStateOf<Bitmap?>(null) }
    val clipboard = remember(context) { context.getSystemService(ClipboardManager::class.java) }
    val scope = rememberCoroutineScope()
    val pulse by rememberInfiniteTransition(label = "login-pulse").animateFloat(
        initialValue = 0.98f,
        targetValue = 1.03f,
        animationSpec = infiniteRepeatable(tween(1200), RepeatMode.Reverse),
        label = "login-scale"
    )

    LaunchedEffect(Unit) {
        client.config().onSuccess { remote ->
            if (remote.maintenance.enabled) {
                maintenance = remote.maintenance
                if (remote.maintenance.imageUrl.isNotBlank()) {
                    client.maintenanceImage(remote.maintenance.imageUrl).onSuccess { maintenanceImage = it }
                }
            }
        }
    }

    Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFF05070D)) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val compact = maxWidth < 360.dp
            val sidePadding = if (compact) 18.dp else 24.dp
            val logoSize = (maxWidth * 0.44f).coerceIn(112.dp, 164.dp)
            val contentGap = if (maxHeight < 650.dp) 22.dp else 34.dp
            Box(
                modifier = Modifier.fillMaxSize().background(
                    Brush.verticalGradient(listOf(Color(0xFF070B15), Color(0xFF101827), Color(0xFF05070D)))
                )
            )
            Column(
                modifier = Modifier.fillMaxSize().imePadding().navigationBarsPadding().verticalScroll(rememberScrollState()).padding(horizontal = sidePadding, vertical = 26.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Image(
                    painter = painterResource(R.drawable.gustaxy_mark),
                    contentDescription = "Gustaxy",
                    modifier = Modifier.size(logoSize).scale(pulse)
                )
                Text(
                    buildAnnotatedString {
                        withStyle(SpanStyle(color = Color.White, fontWeight = FontWeight.Black)) { append("Gustaxy ") }
                        withStyle(SpanStyle(color = Color(0xFFFF3855), fontWeight = FontWeight.Black)) { append("Android") }
                    },
                    modifier = Modifier.padding(top = 16.dp),
                    fontSize = if (compact) 25.sp else 29.sp,
                    letterSpacing = (-0.5).sp
                )
                Text("Acesso seguro", modifier = Modifier.padding(top = 6.dp), color = Color(0xFF9DA8BC), fontSize = 13.sp)
                Spacer(modifier = Modifier.height(contentGap))
                OutlinedTextField(
                    value = key,
                    onValueChange = { key = it; message = null },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("Key") },
                    placeholder = { Text("Cole sua key") },
                    leadingIcon = { Icon(Icons.Outlined.Key, contentDescription = null) },
                    trailingIcon = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = {
                                val clip = clipboard?.primaryClip
                                val pasted = if (clip != null && clip.itemCount > 0) clip.getItemAt(0).coerceToText(context).toString().trim() else ""
                                if (pasted.isNotEmpty()) {
                                    key = pasted
                                    message = null
                                } else {
                                    message = "Copie uma key antes de colar."
                                }
                            }) {
                                Icon(Icons.Outlined.ContentPaste, contentDescription = "Colar key")
                            }
                            IconButton(onClick = { key = ""; message = null }, enabled = key.isNotEmpty()) {
                                Icon(Icons.Outlined.DeleteOutline, contentDescription = "Limpar key")
                            }
                        }
                    },
                    isError = message != null,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    shape = RoundedCornerShape(16.dp)
                )
                message?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.fillMaxWidth().padding(top = 8.dp), fontSize = 12.sp) }
                Spacer(modifier = Modifier.height(18.dp))
                Button(
                    onClick = {
                        if (key.trim().isEmpty() || loading) {
                            message = "Informe uma key."
                            return@Button
                        }
                        scope.launch {
                            loading = true
                            message = null
                            val deviceId = DeviceInfo.deviceId(context)
                            val report = NativeSecurity.inspect(context, deviceId)
                            if (!BuildConfig.DEBUG && !report.acceptable) {
                                loading = false
                                onInvalidIntegrity()
                                return@launch
                            }
                            val result = client.login(
                                key = key.trim(),
                                deviceId = deviceId,
                                deviceName = DeviceInfo.deviceName(),
                                appVersion = BuildConfig.VERSION_NAME,
                                androidVersion = DeviceInfo.androidVersion(),
                                integrity = mapOf(
                                    "apk_sha256" to report.apkSha256,
                                    "cert_sha256" to report.certificateSha256,
                                    "native_signal" to report.nativeSignal,
                                    "nonce" to report.nonce
                                )
                            )
                            loading = false
                            result.onSuccess { onSuccess() }.onFailure { message = it.message ?: "Não foi possível entrar." }
                        }
                    },
                    enabled = !loading,
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF246BFF), contentColor = Color.White)
                ) {
                    if (loading) CircularProgressIndicator(modifier = Modifier.size(21.dp), color = Color.White, strokeWidth = 2.dp)
                    else Text("Entrar", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedButton(
                    onClick = { message = "Link do grupo ainda não configurado." },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, Color(0xFF33435F)),
                    colors = androidx.compose.material3.ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFB9C8E4))
                ) { Text("Grupo WhatsApp", fontSize = 14.sp, fontWeight = FontWeight.SemiBold) }
            }
        }
    }

    maintenance?.let { info ->
        AlertDialog(
            onDismissRequest = { maintenance = null },
            title = { Text(info.title) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    maintenanceImage?.let { bitmap -> Image(bitmap.asImageBitmap(), contentDescription = "Imagem da manutenção", modifier = Modifier.fillMaxWidth().height(150.dp)) }
                    Text(info.description)
                }
            },
            confirmButton = { TextButton(onClick = { maintenance = null }) { Text("Entendi") } }
        )
    }
}
