package com.gustaxy.android

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Logout
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Wifi
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import com.gustaxy.android.network.ApiClient
import com.gustaxy.android.ui.theme.GustaxyAndroidTheme
import kotlinx.coroutines.launch

class DashboardActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            GustaxyAndroidTheme {
                DashboardScreen(
                    onUnauthorized = {
                        startActivity(Intent(this, LoginActivity::class.java))
                        finish()
                    },
                    onLogout = {
                        lifecycleScope.launch {
                            ApiClient(this@DashboardActivity).logout()
                            startActivity(Intent(this@DashboardActivity, LoginActivity::class.java))
                            finish()
                        }
                    }
                )
            }
        }
    }
}

@Composable
private fun DashboardScreen(onUnauthorized: () -> Unit, onLogout: () -> Unit) {
    val context = LocalContext.current
    var session by remember { mutableStateOf<ApiClient.SessionInfo?>(null) }
    var selectedTab by rememberSaveable { mutableIntStateOf(0) }
    var refreshKey by remember { mutableIntStateOf(0) }
    LaunchedEffect(refreshKey) {
        ApiClient(context).current()
            .onSuccess { session = it }
            .onFailure { onUnauthorized() }
    }
    val activeSession = session ?: return
    val tabs = listOf("Início", "Conexão", "Info", "Sair")
    val icons = listOf(Icons.Outlined.Home, Icons.Outlined.Wifi, Icons.Outlined.Info, Icons.Outlined.Logout)

    Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFF05070D)) {
        Scaffold(
            containerColor = Color.Transparent,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF0D1422), tonalElevation = 0.dp) {
                    tabs.forEachIndexed { index, label ->
                        NavigationBarItem(
                            selected = selectedTab == index,
                            onClick = { if (index == 3) onLogout() else selectedTab = index },
                            icon = { Icon(icons[index], contentDescription = label) },
                            label = { Text(label, fontSize = 11.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color.White,
                                selectedTextColor = Color.White,
                                indicatorColor = Color(0xFF245DCD),
                                unselectedIconColor = Color(0xFF8392AA),
                                unselectedTextColor = Color(0xFF8392AA)
                            )
                        )
                    }
                }
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier.fillMaxSize().background(
                    Brush.verticalGradient(listOf(Color(0xFF09101D), Color(0xFF05070D)))
                ).padding(innerPadding).padding(horizontal = 20.dp, vertical = 18.dp)
            ) {
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { selectedTab = 0 }) {
                        Icon(painterResource(R.drawable.gustaxy_mark), contentDescription = "Gustaxy", tint = Color.Unspecified, modifier = Modifier.size(42.dp))
                    }
                    Text("Gustaxy", modifier = Modifier.padding(start = 8.dp), color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black)
                    Spacer(modifier = Modifier.weight(1f))
                    IconButton(onClick = { refreshKey++ }) { Icon(Icons.Outlined.Refresh, contentDescription = "Atualizar", tint = Color(0xFFB9C8E4)) }
                }
                Spacer(modifier = Modifier.height(20.dp))
                when (selectedTab) {
                    0 -> HomePanel(activeSession)
                    1 -> ConnectionPanel(activeSession)
                    else -> InfoPanel()
                }
            }
        }
    }
}

@Composable
private fun HomePanel(session: ApiClient.SessionInfo) {
    Text("Início", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Black)
    Text("Acesso liberado", modifier = Modifier.padding(top = 6.dp), color = Color(0xFF9DA8BC), fontSize = 14.sp)
    Spacer(modifier = Modifier.height(22.dp))
    StatusCard(title = "Conexão ativa", value = if (session.keysPaused) "Pausada" else "Online", accent = Color(0xFF2B7BFF))
    Spacer(modifier = Modifier.height(12.dp))
    StatusCard(title = "Validade da key", value = session.keyExpiresAt.ifBlank { "Consultando" }, accent = Color(0xFFFF3855))
}

@Composable
private fun ConnectionPanel(session: ApiClient.SessionInfo) {
    Text("Conexão", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Black)
    Text("Status do acesso atual", modifier = Modifier.padding(top = 6.dp), color = Color(0xFF9DA8BC), fontSize = 14.sp)
    Spacer(modifier = Modifier.height(22.dp))
    StatusCard(title = "Servidor", value = if (session.keysPaused) "Pausa global" else "Online", accent = Color(0xFF2B7BFF))
    Spacer(modifier = Modifier.height(12.dp))
    StatusCard(title = "Dispositivo", value = session.deviceIdPrefix.ifBlank { "Protegido" }, accent = Color(0xFFFF3855))
}

@Composable
private fun InfoPanel() {
    Text("Info", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Black)
    Text("Gustaxy Android", modifier = Modifier.padding(top = 6.dp), color = Color(0xFF9DA8BC), fontSize = 14.sp)
    Spacer(modifier = Modifier.height(22.dp))
    StatusCard(title = "Versão", value = BuildConfig.VERSION_NAME, accent = Color(0xFF2B7BFF))
    Spacer(modifier = Modifier.height(12.dp))
    StatusCard(title = "Integridade", value = "Nativa ativa", accent = Color(0xFFFF3855))
}

@Composable
private fun StatusCard(title: String, value: String, accent: Color) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF111A2B))
    ) {
        Row(modifier = Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Spacer(modifier = Modifier.width(4.dp).height(42.dp).background(accent, RoundedCornerShape(8.dp)))
            Column(modifier = Modifier.padding(start = 14.dp)) {
                Text(title, color = Color(0xFF9DA8BC), fontSize = 13.sp)
                Text(value, modifier = Modifier.padding(top = 4.dp), color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
