package com.gustaxy.android.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val GustaxyDarkColors = darkColorScheme(
    primary = Color(0xFF2B7BFF),
    onPrimary = Color.White,
    secondary = Color(0xFFFF3855),
    onSecondary = Color.White,
    tertiary = Color(0xFF8AB4FF),
    background = Color(0xFF05070D),
    onBackground = Color(0xFFF7F9FC),
    surface = Color(0xFF111A2B),
    onSurface = Color(0xFFF7F9FC),
    surfaceVariant = Color(0xFF1A263A),
    onSurfaceVariant = Color(0xFF9DA8BC),
    outline = Color(0xFF42516B)
)

@Composable
fun GustaxyAndroidTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = GustaxyDarkColors,
        typography = GustaxyTypography,
        content = content
    )
}
