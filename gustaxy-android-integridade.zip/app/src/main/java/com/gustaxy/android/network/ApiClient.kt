package com.gustaxy.android.network

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.gustaxy.android.BuildConfig
import com.gustaxy.android.security.SecureSessionStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

class ApiClient(context: Context) {
    private val appContext = context.applicationContext
    private val session = SecureSessionStore(appContext)
    private val baseUrl = BuildConfig.API_BASE_URL.trimEnd('/')
    private val primaryHost = runCatching { URL(baseUrl).host.lowercase() }.getOrDefault("")

    /** Temporary x10 virtual-host fallback. TLS remains strict on x12.x10hosting.com. */
    private val virtualHostFallbackBaseUrl = "https://x12.x10hosting.com/api/v1"
    private val virtualHostFallbackName = "gstxonline.x10.mx"
    private val canUseVirtualHostFallback =
        !BuildConfig.DEBUG && primaryHost == virtualHostFallbackName && baseUrl.startsWith("https://")

    data class LoginResult(val token: String, val expiresAt: String, val keyExpiresAt: String)
    data class SessionInfo(val keyExpiresAt: String, val deviceIdPrefix: String, val keysPaused: Boolean)
    data class MaintenanceInfo(val enabled: Boolean, val title: String, val description: String, val imageUrl: String)
    data class RemoteConfig(val maintenance: MaintenanceInfo, val keysPaused: Boolean)

    suspend fun config(): Result<RemoteConfig> = withContext(Dispatchers.IO) {
        val response = runCatching { request("/config", "GET", null, null) }
            .getOrElse { return@withContext Result.failure(IOException("Servidor indisponível.")) }
        if (response.code !in 200..299) return@withContext Result.failure(IOException(response.errorMessage()))
        runCatching {
            val body = JSONObject(response.body)
            val maintenance = body.optJSONObject("maintenance") ?: JSONObject()
            RemoteConfig(
                maintenance = MaintenanceInfo(
                    enabled = maintenance.optBoolean("enabled", false),
                    title = maintenance.optString("title", "Manutenção programada"),
                    description = maintenance.optString("description", "Tente novamente mais tarde."),
                    imageUrl = maintenance.optString("image_url", "")
                ),
                keysPaused = body.optBoolean("keys_paused", false)
            )
        }
    }

    suspend fun maintenanceImage(imageUrl: String): Result<Bitmap?> = withContext(Dispatchers.IO) {
        if (imageUrl.isBlank()) return@withContext Result.success(null)
        runCatching {
            val target = URL(imageUrl)
            if (target.protocol != "https" || !target.host.equals(primaryHost, ignoreCase = true)) {
                throw IOException("Imagem não autorizada")
            }
            val connection = try {
                openHttp(target)
            } catch (error: IOException) {
                if (!canUseVirtualHostFallback) throw error
                val fallbackTarget = URL("https://x12.x10hosting.com${target.file}")
                openHttp(fallbackTarget, virtualHostFallbackName)
            }
            try {
                if (connection.responseCode !in 200..299) throw IOException("Imagem indisponível")
                if (connection.contentLengthLong > 2_097_152) throw IOException("Imagem muito grande")
                connection.inputStream.use { BitmapFactory.decodeStream(it) }
            } finally {
                connection.disconnect()
            }
        }
    }

    suspend fun login(
        key: String,
        deviceId: String,
        deviceName: String,
        appVersion: String,
        androidVersion: String,
        integrity: Map<String, String>
    ): Result<LoginResult> = withContext(Dispatchers.IO) {
        if (!BuildConfig.DEBUG && !baseUrl.startsWith("https://")) {
            return@withContext Result.failure(IOException("API insegura"))
        }
        val json = JSONObject().apply {
            put("key", key.trim())
            put("device_id", deviceId)
            put("device_name", deviceName)
            put("app_version", appVersion)
            put("android_version", androidVersion)
            integrity.forEach { (name, value) -> put(name, value) }
        }
        val response = runCatching { request("/auth/login", "POST", json.toString(), null) }
            .getOrElse { return@withContext Result.failure(IOException("Servidor indisponível.")) }
        if (response.code !in 200..299) return@withContext Result.failure(IOException(response.errorMessage()))
        runCatching {
            val body = JSONObject(response.body)
            val token = body.getString("token")
            LoginResult(token, body.optString("expires_at"), body.optString("key_expires_at")).also {
                session.saveKey(key.trim())
                session.saveToken(token)
            }
        }
    }

    suspend fun current(): Result<SessionInfo> = withContext(Dispatchers.IO) {
        val token = session.readToken() ?: return@withContext Result.failure(IOException("Sessão ausente"))
        val response = runCatching { request("/auth/me", "GET", null, token) }
            .getOrElse { return@withContext Result.failure(IOException("Servidor indisponível.")) }
        if (response.code !in 200..299) {
            session.clearToken()
            return@withContext Result.failure(IOException(response.errorMessage()))
        }
        runCatching {
            val body = JSONObject(response.body)
            SessionInfo(
                keyExpiresAt = body.optString("key_expires_at"),
                deviceIdPrefix = body.optString("device_id"),
                keysPaused = body.optBoolean("keys_paused", false)
            )
        }
    }

    suspend fun logout(): Result<Unit> = withContext(Dispatchers.IO) {
        val token = session.readToken()
        if (token != null) runCatching { request("/auth/logout", "POST", "{}", token) }
        session.clearToken()
        Result.success(Unit)
    }

    fun savedKey(): String? = session.readKey()

    fun hasSession(): Boolean = session.readToken() != null

    private fun request(path: String, method: String, body: String?, bearer: String?): Response {
        return try {
            requestOnce(baseUrl, path, method, body, bearer)
        } catch (error: IOException) {
            if (!canUseVirtualHostFallback) throw error
            requestOnce(virtualHostFallbackBaseUrl, path, method, body, bearer, virtualHostFallbackName)
        }
    }

    private fun requestOnce(
        rootUrl: String,
        path: String,
        method: String,
        body: String?,
        bearer: String?,
        hostOverride: String? = null
    ): Response {
        val connection = openHttp(URL(rootUrl + path), hostOverride).apply {
            requestMethod = method
            doInput = true
            setRequestProperty("Accept", "application/json")
            setRequestProperty("Cache-Control", "no-store")
            setRequestProperty("X-Request-Nonce", UUID.randomUUID().toString())
            setRequestProperty("X-Gustaxy-App", BuildConfig.APPLICATION_ID)
            if (bearer != null) setRequestProperty("Authorization", "Bearer $bearer")
            if (body != null) {
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
            }
        }
        return try {
            if (body != null) connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..399) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            Response(code, text)
        } finally {
            connection.disconnect()
        }
    }

    private fun openHttp(url: URL, hostOverride: String? = null): HttpURLConnection =
        (url.openConnection() as HttpURLConnection).apply {
            connectTimeout = 8_000
            readTimeout = 10_000
            useCaches = false
            if (!hostOverride.isNullOrBlank()) setRequestProperty("Host", hostOverride)
        }

    private data class Response(val code: Int, val body: String) {
        fun errorMessage(): String = runCatching {
            JSONObject(body).optString("error", "Falha na comunicação.")
        }.getOrDefault("Falha na comunicação.")
    }
}
