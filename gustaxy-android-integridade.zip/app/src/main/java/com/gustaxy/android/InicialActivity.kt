package com.gustaxy.android

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gustaxy.android.network.ApiClient
import com.gustaxy.android.security.DeviceInfo
import com.gustaxy.android.security.NativeSecurity
import com.gustaxy.android.ui.theme.GustaxyAndroidTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class InicialActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            GustaxyAndroidTheme {
                InitialScreen { report, hasSession ->
                    if (BuildConfig.DEBUG || report.acceptable) {
                        val destination = if (hasSession) DashboardActivity::class.java else LoginActivity::class.java
                        startActivity(Intent(this, destination))
                        finish()
                    } else {
                        finishAndRemoveTask()
                    }
                }
            }
        }
    }
}

@Composable
private fun InitialScreen(onFinished: (NativeSecurity.Report, Boolean) -> Unit) {
    val progress = remember { Animatable(0f) }
    val context = LocalContext.current
    val pulse by rememberInfiniteTransition(label = "logo-pulse").animateFloat(
        initialValue = 0.96f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(tween(1100), RepeatMode.Reverse),
        label = "logo-scale"
    )
    LaunchedEffect(Unit) {
        val report = withContext(Dispatchers.Default) { NativeSecurity.inspect(context, DeviceInfo.deviceId(context)) }
        progress.animateTo(0.38f, tween(260))
        progress.animateTo(0.78f, tween(320))
        val hasSession = if (BuildConfig.DEBUG || report.acceptable) {
            withContext(Dispatchers.IO) { ApiClient(context).current().isSuccess }
        } else {
            false
        }
        progress.animateTo(1f, tween(300))
        onFinished(report, hasSession)
    }
    Box(modifier = Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(R.drawable.background_gustaxy),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        Box(
            modifier = Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    listOf(Color(0xB300030B), Color(0x3300030B), Color(0xE600030B))
                )
            )
        )
        Column(
            modifier = Modifier.fillMaxSize().padding(horizontal = 28.dp, vertical = 46.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Image(
                painter = painterResource(R.drawable.gustaxy_mark),
                contentDescription = "Gustaxy",
                modifier = Modifier.size(164.dp).scale(pulse).alpha(0.98f)
            )
            Text(
                text = "GUSTAXY",
                modifier = Modifier.padding(top = 22.dp),
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 6.sp
            )
        }
        Column(
            modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(horizontal = 28.dp, vertical = 42.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            CircularProgressIndicator(
                progress = { progress.value },
                modifier = Modifier.size(30.dp),
                color = MaterialTheme.colorScheme.primary,
                trackColor = Color.White.copy(alpha = 0.16f),
                strokeWidth = 3.dp
            )
            Text(
                text = "${(progress.value * 100).toInt()}%",
                modifier = Modifier.padding(top = 12.dp).clip(RoundedCornerShape(20.dp)).alpha(0.82f),
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}
