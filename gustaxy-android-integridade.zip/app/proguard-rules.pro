# O binding JNI por convenção de nome (Java_com_..._Metodo) exige que o NOME
# da classe e o NOME dos métodos native fiquem estáveis — é o que esta regra
# genérica garante. Todo o resto de NativeSecurity (Report, hex(), normalize(),
# certificateBytes()...) fica livre para o R8 renomear/inlinear normalmente,
# ao contrário de antes, que mantinha a classe inteira sem ofuscação.
-keepclasseswithmembers,includedescriptorclasses class * {
    native <methods>;
}

-keepattributes Signature,InnerClasses,EnclosingMethod,*Annotation*

# Keep Compose and Android component metadata required by the generated app.
-keepclassmembers class * {
    @androidx.compose.runtime.Composable <methods>;
}
