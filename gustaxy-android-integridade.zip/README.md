# Gustaxy Android

Aplicativo Android em Jetpack Compose com `InicialActivity`, `LoginActivity` e `DashboardActivity`. O splash agora executa a inicialização real da camada de segurança antes de abrir o login. O login usa a API PHP v1, salva somente o token temporário cifrado pelo Android Keystore e abre o Dashboard após validação server-side.

## Segurança aplicada

O cliente usa HTTPS obrigatório em release, desabilita cleartext e backup, gera um identificador por instalação baseado no `ANDROID_ID` com SHA-256, envia somente metadados mínimos do dispositivo, usa `libgusta.so` com hardening nativo, e rejeita debugger em release. O app consulta `GET /api/v1/config` antes do login e pode exibir um diálogo de manutenção com título, descrição e imagem hospedada no próprio domínio. A validação TLS continua estrita; um certificado emitido para outro host será rejeitado corretamente. Para distribuição pela Google Play, a integração recomendada é Play Integrity com verificação server-side (ainda não implementada aqui).

### Integridade nativa (libgusta.so)

O hash do certificado de assinatura e do APK, a comparação contra os valores esperados e o cálculo do sinal de integridade enviado ao servidor agora rodam em C++ (`app/src/main/cpp/`), não em Kotlin:

- `nativeSha256` — SHA-256 implementado em C++ puro (sem `java.security.MessageDigest`), usado para hashear o certificado de assinatura e o APK. Evita o alvo mais comum de hooks de Frida em apps Android (`MessageDigest.digest()`).
- `nativeIntegritySignal` — assina `cert_sha256|apk_sha256|device_id|nonce` com HMAC-SHA256 usando um segredo embutido só na lib nativa (nunca aparece no `BuildConfig`/DEX). O servidor recalcula esse HMAC de forma independente e só aceita o login se bater — ver `APK_INTEGRITY_SECRET` no backend. Isso fecha uma brecha real: hoje, sem isso, qualquer script pode ler o certificado de um APK publicado (é informação pública) e mandar `cert_sha256` direto pra API sem nunca rodar o app.
- `nativeSecureEquals` — comparação em tempo constante para os checks locais de certificado/APK.
- `nativeDebuggerAttached` — lê `TracerPid` em `/proc/self/status`; complementa (não substitui) `Debug.isDebuggerConnected()`.

O boolean local (`Report.acceptable`) é só um atalho de UX: evita abrir a tela de login sabendo que o servidor vai recusar. **A autoridade de verdade é sempre o servidor**, que recalcula o HMAC de forma independente — um boolean Kotlin remendado (via smali ou hook) não é suficiente para passar, porque o servidor não confia em nada que o app "afirma" sobre si mesmo, só no que consegue derivar de novo com o segredo compartilhado.

`proguard-rules.pro` mantém apenas o nome da classe e dos métodos `native` (exigência da convenção de nomes do JNI); todo o resto de `NativeSecurity` (o `Report`, `hex()`, `normalize()`, `certificateBytes()`...) fica livre para o R8 renomear e inlinear — antes a classe inteira ficava de fora da ofuscação.

Como qualquer proteção client-side, isso não é inquebrável: quem tiver skill de engenharia reversa de binário ARM (Ghidra/IDA) e conseguir extrair o segredo do `.so` ainda consegue forjar o sinal. O ganho real é elevar bastante o esforço necessário — sai de "abrir o Jadx e trocar um `true`/`false`" para "desmontar uma lib nativa compilada" — e fechar a brecha de scripts que nunca chegam a rodar o app.

O perfil release usa R8 com shrinking, otimização, remoção de recursos e ofuscação. O keystore de release não deve entrar no ZIP nem no repositório: o workflow recebe o arquivo base64 e senhas por GitHub Secrets.

## Configuração de build

O workflow aceita `GUSTAXY_API_BASE_URL`, `GUSTAXY_CERT_SHA256`, `GUSTAXY_APK_SHA256` e `GUSTAXY_INTEGRITY_SECRET`. O URL padrão de produção é `https://gstxonline.x10.mx/api/v1`; os segredos devem ser mantidos no GitHub para facilitar mudanças futuras. `GUSTAXY_INTEGRITY_SECRET` é texto puro (o build já converte pra hex antes de repassar pro C++, então não precisa converter nada manualmente) e deve ser o mesmo valor configurado como `APK_INTEGRITY_SECRET` no `config/env.php` do backend — combine um valor longo e aleatório (32+ caracteres) e trate como qualquer outra senha: nunca no repositório, só como GitHub Secret. O logo GSTX PROXY é usado no splash, login, dashboard e ícone do aplicativo. O botão Paste usa o ClipboardManager do Android em primeiro plano e informa quando o clipboard estiver vazio. Para assinar, configure `GUSTAXY_KEYSTORE_B64`, `GUSTAXY_KEYSTORE_PASSWORD`, `GUSTAXY_KEY_ALIAS` e `GUSTAXY_KEY_PASSWORD` como secrets do GitHub. O keystore gerado deve ser guardado pelo proprietário em local seguro, com cópia offline.
