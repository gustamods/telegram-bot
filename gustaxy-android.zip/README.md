# Gustaxy Android

Aplicativo Android em Jetpack Compose com `InicialActivity`, `LoginActivity` e `DashboardActivity`. O splash agora executa a inicialização real da camada de segurança antes de abrir o login. O login usa a API PHP v1, salva somente o token temporário cifrado pelo Android Keystore e abre o Dashboard após validação server-side.

## Segurança aplicada

O cliente usa HTTPS obrigatório em release, desabilita cleartext e backup, gera um identificador por instalação baseado no `ANDROID_ID` com SHA-256, envia somente metadados mínimos do dispositivo, usa `libgusta.so` com hardening nativo, verifica localmente o certificado de assinatura e o SHA-256 do APK quando os valores esperados são configurados, e rejeita debugger em release. O app consulta `GET /api/v1/config` antes do login e pode exibir um diálogo de manutenção com título, descrição e imagem hospedada no próprio domínio. A validação TLS continua estrita; um certificado emitido para outro host será rejeitado corretamente. Essas checagens locais são sinais complementares; o servidor continua sendo a autoridade para keys, tokens, revogação e limite de dispositivos. Para distribuição pela Google Play, a integração recomendada é Play Integrity com verificação server-side.

O perfil release usa R8 com shrinking, otimização, remoção de recursos e ofuscação. O keystore de release não deve entrar no ZIP nem no repositório: o workflow recebe o arquivo base64 e senhas por GitHub Secrets.

## Configuração de build

O workflow aceita `GUSTAXY_API_BASE_URL`, `GUSTAXY_CERT_SHA256` e `GUSTAXY_APK_SHA256`. O URL padrão de produção é `https://gstxonline.x10.mx/api/v1`; o segredo deve ser mantido no GitHub para facilitar mudanças futuras. O logo GSTX PROXY é usado no splash, login, dashboard e ícone do aplicativo. O botão Paste usa o ClipboardManager do Android em primeiro plano e informa quando o clipboard estiver vazio. Para assinar, configure `GUSTAXY_KEYSTORE_B64`, `GUSTAXY_KEYSTORE_PASSWORD`, `GUSTAXY_KEY_ALIAS` e `GUSTAXY_KEY_PASSWORD` como secrets do GitHub. O keystore gerado deve ser guardado pelo proprietário em local seguro, com cópia offline.
