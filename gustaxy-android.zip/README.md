# Gustaxy Android

Projeto Android inicial em **Jetpack Compose** com duas Activities:

- `InicialActivity.kt`: splash com logo PNG transparente, imagem de fundo e progresso animado de 0% a 100% em aproximadamente 1000 ms.
- `LoginActivity.kt`: logo, título `Gustaxy Android` com as cores solicitadas, campo `Key`, ações `Paste` e `Clear`, botão azul `Login` e botão `Grupo Whatsapp`.

O botão de Login e o botão de Grupo Whatsapp estão preparados como pontos de extensão. A validação da Key e a URL do grupo serão adicionadas quando forem definidas.

## Build local

```bash
./gradlew :app:assembleDebug
```

O APK de debug será gerado em `app/build/outputs/apk/debug/app-debug.apk`.

## Assets

Os arquivos `logo_gustaxy.png` e `background_gustaxy.png` são placeholders visuais incluídos para que o projeto funcione imediatamente. Eles podem ser substituídos pelos assets oficiais mantendo os mesmos nomes ou atualizando as referências nas Activities.
