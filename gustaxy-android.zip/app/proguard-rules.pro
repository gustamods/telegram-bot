# Keep only the JNI bridge name; the rest of the application is eligible for R8 obfuscation.
-keep class com.gustaxy.android.security.NativeSecurity { *; }
-keepclasseswithmembers,includedescriptorclasses class * {
    native <methods>;
}

-keepattributes Signature,InnerClasses,EnclosingMethod,*Annotation*

# Keep Compose and Android component metadata required by the generated app.
-keepclassmembers class * {
    @androidx.compose.runtime.Composable <methods>;
}
