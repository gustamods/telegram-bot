# Regras específicas do projeto podem ser adicionadas aqui quando o release for configurado.
