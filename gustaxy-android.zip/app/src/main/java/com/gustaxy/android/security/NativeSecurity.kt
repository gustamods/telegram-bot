package com.gustaxy.android.security

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Debug
import com.gustaxy.android.BuildConfig
import java.io.FileInputStream
import java.security.MessageDigest
import java.util.Locale

object NativeSecurity {
    private var nativeLoaded = false

    init {
        nativeLoaded = try {
            System.loadLibrary("gusta")
            true
        } catch (_: UnsatisfiedLinkError) {
            false
        }
    }

    private external fun nativeBuildSignal(input: String): String

    data class Report(
        val nativeLoaded: Boolean,
        val nativeSignal: String,
        val certificateSha256: String,
        val apkSha256: String,
        val signatureMatches: Boolean,
        val apkMatches: Boolean,
        val debuggerAttached: Boolean,
    ) {
        val acceptable: Boolean
            get() = nativeLoaded && signatureMatches && apkMatches && !debuggerAttached
    }

    fun inspect(context: Context): Report {
        val cert = certificateSha256(context)
        val apk = fileSha256(context.applicationInfo.sourceDir)
        val expectedCert = normalize(BuildConfig.EXPECTED_CERT_SHA256)
        val expectedApk = normalize(BuildConfig.EXPECTED_APK_SHA256)
        return Report(
            nativeLoaded = nativeLoaded,
            nativeSignal = if (nativeLoaded) runCatching { nativeBuildSignal(BuildConfig.APPLICATION_ID) }.getOrDefault("") else "",
            certificateSha256 = cert,
            apkSha256 = apk,
            signatureMatches = expectedCert.isBlank() || cert == expectedCert,
            apkMatches = expectedApk.isBlank() || apk == expectedApk,
            debuggerAttached = Debug.isDebuggerConnected() || Debug.waitingForDebugger(),
        )
    }

    private fun certificateSha256(context: Context): String = runCatching {
        val packageInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            context.packageManager.getPackageInfo(context.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
        } else {
            @Suppress("DEPRECATION")
            context.packageManager.getPackageInfo(context.packageName, PackageManager.GET_SIGNATURES)
        }
        val signature = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            packageInfo.signingInfo?.apkContentsSigners?.firstOrNull()
        } else {
            @Suppress("DEPRECATION")
            packageInfo.signatures?.firstOrNull()
        } ?: return@runCatching ""
        normalize(hex(MessageDigest.getInstance("SHA-256").digest(signature.toByteArray())))
    }.getOrDefault("")

    private fun fileSha256(path: String): String = runCatching {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(path).use { input ->
            val buffer = ByteArray(8192)
            while (true) {
                val count = input.read(buffer)
                if (count <= 0) break
                digest.update(buffer, 0, count)
            }
        }
        normalize(hex(digest.digest()))
    }.getOrDefault("")

    private fun normalize(value: String): String = value.replace(":", "").replace("-", "").trim().uppercase(Locale.ROOT)

    private fun hex(bytes: ByteArray): String = bytes.joinToString("") { "%02X".format(Locale.ROOT, it) }
}
