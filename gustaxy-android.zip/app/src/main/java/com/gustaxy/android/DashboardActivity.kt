package com.gustaxy.android

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Logout
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import com.gustaxy.android.network.ApiClient
import com.gustaxy.android.ui.theme.GustaxyAndroidTheme
import kotlinx.coroutines.launch

class DashboardActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            GustaxyAndroidTheme {
                DashboardScreen(
                    onUnauthorized = {
                        startActivity(Intent(this, LoginActivity::class.java))
                        finish()
                    },
                    onLogout = {
                        lifecycleScope.launch {
                            ApiClient(this@DashboardActivity).logout()
                            startActivity(Intent(this@DashboardActivity, LoginActivity::class.java))
                            finish()
                        }
                    }
                )
            }
        }
    }
}

@Composable
private fun DashboardScreen(onUnauthorized: () -> Unit, onLogout: () -> Unit) {
    val context = LocalContext.current
    var ready by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        ready = ApiClient(context).current().isSuccess
        if (!ready) onUnauthorized()
    }
    if (!ready) return
    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(modifier = Modifier.fillMaxSize().background(Color(0xFF0B0D12)).padding(22.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                DashboardMark()
                Text("Gustaxy", modifier = Modifier.padding(start = 14.dp), color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.weight(1f))
                IconButton(onClick = onLogout) { Icon(Icons.Outlined.Logout, contentDescription = "Sair", tint = Color.White) }
            }
            Spacer(modifier = Modifier.height(42.dp))
            Text("Dashboard", color = Color.White, fontSize = 24.sp)
            Text("Sessão validada pelo servidor.", modifier = Modifier.padding(top = 8.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(28.dp))
            Button(onClick = onLogout, modifier = Modifier.fillMaxWidth().height(52.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1976D2))) { Text("Sair") }
        }
    }
}

@Composable
private fun DashboardMark() {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp), horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.size(width = 22.dp, height = 28.dp)) {
        Box(Modifier.size(width = 4.dp, height = 5.dp).background(Color(0xFFE53935)))
        Box(Modifier.size(width = 4.dp, height = 7.dp).background(Color(0xFFE53935)))
        Box(Modifier.size(width = 4.dp, height = 9.dp).background(Color(0xFFE53935)))
    }
}
