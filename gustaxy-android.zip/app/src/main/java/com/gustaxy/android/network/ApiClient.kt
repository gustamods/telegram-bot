package com.gustaxy.android.network

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.gustaxy.android.BuildConfig
import com.gustaxy.android.security.SecureSessionStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

class ApiClient(context: Context) {
    private val appContext = context.applicationContext
    private val session = SecureSessionStore(appContext)
    private val baseUrl = BuildConfig.API_BASE_URL.trimEnd('/')

    data class LoginResult(val token: String, val expiresAt: String, val keyExpiresAt: String)
    data class MaintenanceInfo(val enabled: Boolean, val title: String, val description: String, val imageUrl: String)
    data class RemoteConfig(val maintenance: MaintenanceInfo, val keysPaused: Boolean)

    suspend fun config(): Result<RemoteConfig> = withContext(Dispatchers.IO) {
        val response = request("/config", "GET", null, null)
        if (response.code !in 200..299) return@withContext Result.failure(IOException(response.errorMessage()))
        runCatching {
            val body = JSONObject(response.body)
            val maintenance = body.optJSONObject("maintenance") ?: JSONObject()
            RemoteConfig(
                maintenance = MaintenanceInfo(
                    enabled = maintenance.optBoolean("enabled", false),
                    title = maintenance.optString("title", "Manutenção programada"),
                    description = maintenance.optString("description", "Tente novamente mais tarde."),
                    imageUrl = maintenance.optString("image_url", "")
                ),
                keysPaused = body.optBoolean("keys_paused", false)
            )
        }
    }

    suspend fun maintenanceImage(imageUrl: String): Result<Bitmap?> = withContext(Dispatchers.IO) {
        if (imageUrl.isBlank()) return@withContext Result.success(null)
        runCatching {
            val target = URL(imageUrl)
            val base = URL(baseUrl)
            if (target.protocol != "https" || target.host != base.host) throw IOException("Imagem não autorizada")
            val connection = (target.openConnection() as HttpURLConnection).apply {
                connectTimeout = 8_000
                readTimeout = 10_000
                useCaches = false
                setRequestProperty("Accept", "image/png,image/jpeg,image/webp,image/gif")
            }
            try {
                if (connection.responseCode !in 200..299) throw IOException("Imagem indisponível")
                val length = connection.contentLengthLong
                if (length > 2_097_152) throw IOException("Imagem muito grande")
                connection.inputStream.use { BitmapFactory.decodeStream(it) }
            } finally {
                connection.disconnect()
            }
        }
    }

    suspend fun login(key: String, deviceId: String, deviceName: String, appVersion: String, androidVersion: String, integrity: Map<String, String>): Result<LoginResult> = withContext(Dispatchers.IO) {
        if (!BuildConfig.DEBUG && !baseUrl.startsWith("https://")) return@withContext Result.failure(IOException("API insegura"))
        val json = JSONObject().apply {
            put("key", key)
            put("device_id", deviceId)
            put("device_name", deviceName)
            put("app_version", appVersion)
            put("android_version", androidVersion)
            integrity.forEach { (name, value) -> put(name, value) }
        }
        val response = request("/auth/login", "POST", json.toString(), null)
        if (response.code !in 200..299) return@withContext Result.failure(IOException(response.errorMessage()))
        runCatching {
            val body = JSONObject(response.body)
            val token = body.getString("token")
            LoginResult(token, body.optString("expires_at"), body.optString("key_expires_at")).also { session.save(token) }
        }
    }

    suspend fun current(): Result<String> = withContext(Dispatchers.IO) {
        val token = session.read() ?: return@withContext Result.failure(IOException("Sessão ausente"))
        val response = request("/auth/me", "GET", null, token)
        if (response.code !in 200..299) {
            session.clear()
            return@withContext Result.failure(IOException(response.errorMessage()))
        }
        Result.success(response.body)
    }

    suspend fun logout(): Result<Unit> = withContext(Dispatchers.IO) {
        val token = session.read()
        if (token != null) request("/auth/logout", "POST", "{}", token)
        session.clear()
        Result.success(Unit)
    }

    fun hasSession(): Boolean = session.read() != null

    private fun request(path: String, method: String, body: String?, bearer: String?): Response {
        val connection = (URL(baseUrl + path).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 8_000
            readTimeout = 10_000
            useCaches = false
            doInput = true
            setRequestProperty("Accept", "application/json")
            setRequestProperty("Cache-Control", "no-store")
            setRequestProperty("X-Request-Nonce", UUID.randomUUID().toString())
            setRequestProperty("X-Gustaxy-App", BuildConfig.APPLICATION_ID)
            if (bearer != null) setRequestProperty("Authorization", "Bearer $bearer")
            if (body != null) {
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
            }
        }
        return try {
            if (body != null) connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..399) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            Response(code, text)
        } finally {
            connection.disconnect()
        }
    }

    private data class Response(val code: Int, val body: String) {
        fun errorMessage(): String = runCatching { JSONObject(body).optString("error", "Falha na comunicação.") }.getOrDefault("Falha na comunicação.")
    }
}
