package com.gustaxy.android.network

import android.content.Context
import com.gustaxy.android.BuildConfig
import com.gustaxy.android.security.SecureSessionStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

class ApiClient(context: Context) {
    private val appContext = context.applicationContext
    private val session = SecureSessionStore(appContext)
    private val baseUrl = BuildConfig.API_BASE_URL.trimEnd('/')

    data class LoginResult(val token: String, val expiresAt: String, val keyExpiresAt: String)

    suspend fun login(key: String, deviceId: String, deviceName: String, appVersion: String, androidVersion: String, integrity: Map<String, String>): Result<LoginResult> = withContext(Dispatchers.IO) {
        if (!BuildConfig.DEBUG && !baseUrl.startsWith("https://")) return@withContext Result.failure(IOException("API insegura"))
        val json = JSONObject().apply {
            put("key", key)
            put("device_id", deviceId)
            put("device_name", deviceName)
            put("app_version", appVersion)
            put("android_version", androidVersion)
            integrity.forEach { (name, value) -> put(name, value) }
        }
        val response = request("/auth/login", "POST", json.toString(), null)
        if (response.code !in 200..299) return@withContext Result.failure(IOException(response.errorMessage()))
        runCatching {
            val body = JSONObject(response.body)
            val token = body.getString("token")
            LoginResult(token, body.optString("expires_at"), body.optString("key_expires_at")).also { session.save(token) }
        }
    }

    suspend fun current(): Result<String> = withContext(Dispatchers.IO) {
        val token = session.read() ?: return@withContext Result.failure(IOException("Sessão ausente"))
        val response = request("/auth/me", "GET", null, token)
        if (response.code !in 200..299) {
            session.clear()
            return@withContext Result.failure(IOException(response.errorMessage()))
        }
        Result.success(response.body)
    }

    suspend fun logout(): Result<Unit> = withContext(Dispatchers.IO) {
        val token = session.read()
        if (token != null) request("/auth/logout", "POST", "{}", token)
        session.clear()
        Result.success(Unit)
    }

    fun hasSession(): Boolean = session.read() != null

    private fun request(path: String, method: String, body: String?, bearer: String?): Response {
        val connection = (URL(baseUrl + path).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 8_000
            readTimeout = 10_000
            useCaches = false
            doInput = true
            setRequestProperty("Accept", "application/json")
            setRequestProperty("Cache-Control", "no-store")
            setRequestProperty("X-Request-Nonce", UUID.randomUUID().toString())
            setRequestProperty("X-Gustaxy-App", BuildConfig.APPLICATION_ID)
            if (bearer != null) setRequestProperty("Authorization", "Bearer $bearer")
            if (body != null) {
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
            }
        }
        return try {
            if (body != null) connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..399) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            Response(code, text)
        } finally {
            connection.disconnect()
        }
    }

    private data class Response(val code: Int, val body: String) {
        fun errorMessage(): String = runCatching { JSONObject(body).optString("error", "Falha na comunicação.") }.getOrDefault("Falha na comunicação.")
    }
}
