package com.gustaxy.android.ui.theme

import androidx.compose.material3.Typography

val GustaxyTypography = Typography()
