package com.gustaxy.android.security

import android.content.Context
import android.os.Build
import android.provider.Settings
import android.util.Base64
import com.gustaxy.android.BuildConfig
import java.nio.charset.StandardCharsets
import java.security.MessageDigest

object DeviceInfo {
    fun deviceId(context: Context): String {
        val androidId = Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID).orEmpty()
        val raw = "${BuildConfig.APPLICATION_ID}:$androidId"
        return Base64.encodeToString(MessageDigest.getInstance("SHA-256").digest(raw.toByteArray(StandardCharsets.UTF_8)), Base64.NO_WRAP)
    }

    fun deviceName(): String = "${Build.MANUFACTURER} ${Build.MODEL}".trim().take(120)
    fun androidVersion(): String = Build.VERSION.RELEASE.orEmpty().take(32)
}
