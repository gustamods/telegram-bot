package com.gustaxy.android

import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ContentPaste
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Key
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gustaxy.android.network.ApiClient
import com.gustaxy.android.security.DeviceInfo
import com.gustaxy.android.security.NativeSecurity
import com.gustaxy.android.ui.theme.GustaxyAndroidTheme
import kotlinx.coroutines.launch

class LoginActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            GustaxyAndroidTheme {
                LoginScreen(onSuccess = {
                    startActivity(android.content.Intent(this, DashboardActivity::class.java))
                    finish()
                }, onInvalidIntegrity = {
                    finishAndRemoveTask()
                })
            }
        }
    }
}

@Composable
private fun LoginScreen(onSuccess: () -> Unit, onInvalidIntegrity: () -> Unit) {
    var key by rememberSaveable { mutableStateOf("") }
    var loading by rememberSaveable { mutableStateOf(false) }
    var message by rememberSaveable { mutableStateOf<String?>(null) }
    val clipboardManager = LocalClipboardManager.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Box(modifier = Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF11131A), MaterialTheme.colorScheme.background, Color(0xFF0B0D12))))) {
            Column(
                modifier = Modifier.fillMaxSize().imePadding().navigationBarsPadding().padding(horizontal = 28.dp, vertical = 30.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Image(painter = painterResource(R.drawable.logo_gustaxy), contentDescription = "Logo Gustaxy", modifier = Modifier.size(116.dp))
                Text(buildAnnotatedString {
                    withStyle(SpanStyle(color = Color.White, fontWeight = FontWeight.Bold)) { append("Gustaxy ") }
                    withStyle(SpanStyle(color = Color(0xFFE53935), fontWeight = FontWeight.Bold)) { append("Android") }
                }, modifier = Modifier.padding(top = 18.dp), fontSize = 27.sp)
                Text("Entre com sua Key para continuar", modifier = Modifier.padding(top = 8.dp), color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp)
                Spacer(modifier = Modifier.height(30.dp))
                OutlinedTextField(
                    value = key,
                    onValueChange = { key = it; message = null },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("Key") },
                    placeholder = { Text("Digite ou cole sua Key") },
                    leadingIcon = { Icon(Icons.Outlined.Key, contentDescription = null) },
                    trailingIcon = { Row(verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = { clipboardManager.getText()?.text?.let { key = it } }, enabled = clipboardManager.getText() != null) { Icon(Icons.Outlined.ContentPaste, contentDescription = "Colar Key", modifier = Modifier.size(17.dp)); Text("Paste", modifier = Modifier.padding(start = 4.dp), fontSize = 12.sp) }
                        IconButton(onClick = { key = "" }, enabled = key.isNotEmpty()) { Icon(Icons.Outlined.DeleteOutline, contentDescription = "Limpar Key") }
                    }},
                    isError = message != null,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    shape = RoundedCornerShape(14.dp)
                )
                message?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.fillMaxWidth().padding(top = 8.dp), fontSize = 13.sp) }
                Spacer(modifier = Modifier.height(22.dp))
                Button(
                    onClick = {
                        if (key.trim().isEmpty() || loading) { message = "Informe uma Key válida."; return@Button }
                        scope.launch {
                            loading = true
                            message = null
                            val report = NativeSecurity.inspect(context)
                            if (!BuildConfig.DEBUG && !report.acceptable) {
                                loading = false
                                onInvalidIntegrity()
                                return@launch
                            }
                            val result = ApiClient(context).login(
                                key = key.trim(),
                                deviceId = DeviceInfo.deviceId(context),
                                deviceName = DeviceInfo.deviceName(),
                                appVersion = BuildConfig.VERSION_NAME,
                                androidVersion = DeviceInfo.androidVersion(),
                                integrity = mapOf("apk_sha256" to report.apkSha256, "cert_sha256" to report.certificateSha256, "native_signal" to report.nativeSignal)
                            )
                            loading = false
                            result.onSuccess { onSuccess() }.onFailure { message = it.message ?: "Não foi possível entrar." }
                        }
                    },
                    enabled = !loading,
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1976D2), contentColor = Color.White)
                ) { if (loading) CircularProgressIndicator(modifier = Modifier.size(21.dp), color = Color.White, strokeWidth = 2.dp) else Text("Login", fontSize = 16.sp, fontWeight = FontWeight.SemiBold) }
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedButton(onClick = { }, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF67D391))) { Text("Grupo Whatsapp", fontSize = 16.sp, fontWeight = FontWeight.Medium) }
            }
        }
    }
}
