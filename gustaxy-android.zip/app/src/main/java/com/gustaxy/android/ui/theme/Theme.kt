package com.gustaxy.android.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val GustaxyDarkColors = darkColorScheme(
    primary = Color(0xFF4EA1FF),
    onPrimary = Color.White,
    secondary = Color(0xFF67D391),
    onSecondary = Color(0xFF062B16),
    background = Color(0xFF0B0D12),
    onBackground = Color(0xFFF5F5F5),
    surface = Color(0xFF151821),
    onSurface = Color(0xFFF5F5F5),
    surfaceVariant = Color(0xFF242832),
    onSurfaceVariant = Color(0xFFB8BEC9),
    outline = Color(0xFF717986)
)

@Composable
fun GustaxyAndroidTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme || isSystemInDarkTheme()) {
        GustaxyDarkColors
    } else {
        GustaxyDarkColors
    }

    MaterialTheme(
        colorScheme = colors,
        typography = GustaxyTypography,
        content = content
    )
}
