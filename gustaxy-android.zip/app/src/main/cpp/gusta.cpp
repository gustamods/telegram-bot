#include <jni.h>
#include <string>

extern "C" JNIEXPORT jstring JNICALL
Java_com_gustaxy_android_security_NativeSecurity_nativeBuildSignal(JNIEnv* env, jobject, jstring input) {
    const char* raw = env->GetStringUTFChars(input, nullptr);
    std::string value = raw ? raw : "";
    if (raw) {
        env->ReleaseStringUTFChars(input, raw);
    }
    unsigned long long state = 1469598103934665603ULL;
    for (unsigned char c : value) {
        state ^= c;
        state *= 1099511628211ULL;
    }
    state ^= 0x47555354415859ULL;
    char output[32];
    snprintf(output, sizeof(output), "gusta-%016llx", state);
    return env->NewStringUTF(output);
}
