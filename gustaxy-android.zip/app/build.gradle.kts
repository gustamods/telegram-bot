plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

val configuredApiBaseUrl = (System.getenv("GUSTAXY_API_BASE_URL")?.takeIf { it.isNotBlank() } ?: "https://gstxonline.x10.mx/api/v1")
    .replace("\\", "\\\\")
    .replace("\"", "\\\"")
val configuredCertificateSha256 = (System.getenv("GUSTAXY_CERT_SHA256")?.takeIf { it.isNotBlank() } ?: "")
    .replace("\\", "\\\\")
    .replace("\"", "\\\"")
val configuredApkSha256 = (System.getenv("GUSTAXY_APK_SHA256")?.takeIf { it.isNotBlank() } ?: "")
    .replace("\\", "\\\\")
    .replace("\"", "\\\"")
val releaseStorePath = System.getenv("GUSTAXY_KEYSTORE_PATH")
val releaseStorePassword = System.getenv("GUSTAXY_KEYSTORE_PASSWORD")
val releaseKeyAlias = System.getenv("GUSTAXY_KEY_ALIAS")
val releaseKeyPassword = System.getenv("GUSTAXY_KEY_PASSWORD") ?: releaseStorePassword

android {
    namespace = "com.gustaxy.android"
    compileSdk = 35
    ndkVersion = "26.3.11579264"

    defaultConfig {
        applicationId = "com.gustaxy.android"
        minSdk = 24
        targetSdk = 35
        versionCode = 2
        versionName = "1.1.0"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables { useSupportLibrary = true }
        buildConfigField("String", "API_BASE_URL", "\"$configuredApiBaseUrl\"")
        buildConfigField("String", "EXPECTED_CERT_SHA256", "\"$configuredCertificateSha256\"")
        buildConfigField("String", "EXPECTED_APK_SHA256", "\"$configuredApkSha256\"")
    }

    signingConfigs {
        create("release") {
            if (!releaseStorePath.isNullOrBlank()) {
                storeFile = file(releaseStorePath)
                storePassword = releaseStorePassword
                keyAlias = releaseKeyAlias
                keyPassword = releaseKeyPassword
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            if (!releaseStorePath.isNullOrBlank()) {
                signingConfig = signingConfigs.getByName("release")
            }
        }
        debug {
            applicationIdSuffix = ".debug"
            versionNameSuffix = "-debug"
        }
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true; buildConfig = true }
    packaging { resources { excludes += "/META-INF/{AL2.0,LGPL2.1}" } }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.12.01")
    implementation(composeBom)
    androidTestImplementation(composeBom)
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.activity:activity-compose:1.10.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    debugImplementation("androidx.compose.ui:ui-tooling")
    debugImplementation("androidx.compose.ui:ui-test-manifest")
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.6.1")
    androidTestImplementation("androidx.compose.ui:ui-test-junit4")
}
